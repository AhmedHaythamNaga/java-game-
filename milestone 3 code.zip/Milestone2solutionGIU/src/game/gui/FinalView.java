package game.gui;

import javafx.application.Application;
import javafx.geometry.Insets;





import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.PriorityQueue;

import game.engine.Battle;
import game.engine.exceptions.InsufficientResourcesException;
import game.engine.exceptions.InvalidLaneException;
import game.engine.lanes.Lane;
import game.engine.titans.AbnormalTitan;
import game.engine.titans.ColossalTitan;
import game.engine.titans.PureTitan;
import game.engine.titans.Titan;
public class FinalView extends Application{
  
   private int currentLane;
   private static Battle battle;
  private final String urlPure="file:///Users/ahmed/Downloads/beast.jpg";//change to collosal
  private final String urlArmored="file:///Users/ahmed/Downloads/armoredTitan.jpeg";  
  private final String urlColosal="file:///Users/ahmed/Downloads/pure.jpeg";
  private final String urlAbnormal="file:///Users/ahmed/Downloads/eren.jpg";
   private void displayAlert(String title, String message) {
       Stage alertStage = new Stage();
       alertStage.setTitle(title);
       Label label = new Label(message);
       Button closeButton = new Button("kml wla yhmk");
       //closing is predefined
       closeButton.setOnAction(event -> alertStage.close());
       BorderPane pane = new BorderPane();
       pane.setTop(label);
       pane.setCenter(closeButton);
       Scene scene = new Scene(pane, 500, 100);
       alertStage.setScene(scene);
       alertStage.show();
   }
   
  public ImageView getPureTitanImage() {
	   
	  Image res= new Image(urlPure);
	  ImageView rat=new ImageView(res);
	  rat.setFitWidth(60);
	  rat.setFitHeight(150);
	  return  rat;
   }
  public ImageView getArmoredTitanImage() {
	  Image res= new Image(urlArmored);
	  ImageView rat=new ImageView(res);
	  rat.setFitWidth(40);
	  rat.setFitHeight(150);
	  return rat;
  }
  public ImageView getCollosalTitanImage() {
	   
	  Image res= new Image(urlColosal);
	  ImageView rat=new ImageView(res);
	  rat.setFitWidth(100);
	  rat.setFitHeight(200);
	  return rat;
  }
  public ImageView getAbnormalTitanImage() {
	   
	  Image res= new Image(urlAbnormal);
	  ImageView rat=new ImageView(res);
	  rat.setFitWidth(70);
	  rat.setFitHeight(100);
	  return rat;
  }

   public  void gameEasy() throws IOException {
		  this.battle=new Battle(1,0,60,3,250);
	  }
   public  void gameDiff() throws IOException {
		  this.battle=new Battle(1,0,60,5,125);
	  }
   public String updateWall1Health() {
	   int temp=this.battle.getOriginalLanes().get(0).getLaneWall().getCurrentHealth();
	   String ret=""+ temp;
	   return "Health=  "+ret;
   }
   public String updateWall2Health() {
	   int temp=this.battle.getOriginalLanes().get(1).getLaneWall().getCurrentHealth();
	   String ret=""+ temp;
	   return "Health= "+ret;
   }
   public String updateWall3Health() {
	   int temp=this.battle.getOriginalLanes().get(2).getLaneWall().getCurrentHealth();
	   String ret=""+ temp;
	   return "Health= "+ret;
   }
   public String updateWall4Health() {
	   int temp=this.battle.getOriginalLanes().get(3).getLaneWall().getCurrentHealth();
	   String ret=""+ temp;
	   return "Health= "+ret;}
  
   public String updatelane1Dl() {
	   int temp=this.battle.getOriginalLanes().get(0).getDangerLevel();
	   String ret=""+temp;
	   return "Danger Level= " +ret;
   }
   public String updatelane2Dl() {
	   int temp=this.battle.getOriginalLanes().get(1).getDangerLevel();
	   String ret=""+temp;
	   return "Danger Level= " +ret;
   }
   public String updatelane3Dl() {
	   int temp=this.battle.getOriginalLanes().get(2).getDangerLevel();
	   String ret=""+temp;
	   return "Danger Level= " +ret;
   }
   public String updatelane4Dl() {
	   int temp=this.battle.getOriginalLanes().get(3).getDangerLevel();
	   String ret=""+temp;
	   return "Danger Level= " +ret;
   }
   public String updatelane5Dl() {
	   int temp=this.battle.getOriginalLanes().get(4).getDangerLevel();
	   String ret=""+temp;
	   return "Danger Level= " +ret;
   }
public void start(Stage primaryStage) throws Exception {
  String s = "Winning and losing Conditions: The game will have no winning"+
			  "\ncondition and the player will keep playing and defeat as many enemies as"+
			  "\npossible. The player loses when all the starting lanes become lost lanes"+
			  "\n(All their Wall Parts are destroyed) and the accumulated score by then is"+
			  "\nthe player’s final score."+
			  "\nTitan Movement: Each turn, every titan inside all of the active lanes that"+
			  "\nhas not reached the walls yet will move closer to the wall (The distance"+
			  "\nfrom the wall will decrease) a distance equal to their speed stat. Note that"+
			  "\nColossal titans gain an extra speed of 1 “Distance Unit” per movement"+
			  "action."+
			  "\nAttack Actions: Both Titans and Weapons are able to perform attack"+
			  "actions:"+
			  "\n1- Titans: Each turn, only titans inside active lanes that have already"+
			  "\nreached the wall (distance from wall is 0) will perform their attack action"+
			  "\non the wall part of their lane (reducing the Wall Part’s HP by the amount of"+
			  "\nthat Titan’s damage). Note that Abnormal Titans perform their attack"+
			  "\nactions twice per turn."+
			  "\n 2- Weapons: Each turn, only weapons that are deployed into active lanes"+
			  "\nwill perform their attack action on the titans their lane (reducing the"+
			  "\nTitans’ HP by the amount of that Weapon’s damage). Each weapon will"+
			  "\nfollow the above weapons table on which titans to attack."+
			  "\nDefeated Attack Targets: Since Titans and Wall Parts can be attacked,"+
			  "\nthey can be defeated/destroyed. This happens when the attack target’s HP"+
			  "\nis dropped to 0 or below as a result of an attack. Defeated Titans are"+
			  "\nremoved from the lanes they were in (and the game) and their resources"+
			  "\nvalue is added to the player’s gathered resources as well as the player’s"+
			  "\nscore (score increases with the same value as the gathered resources). If a"+
			  "\nWall Part is destroyed, the lane with this Wall Part is then marked as a Lost"+
			  "\nLane and not an active Lane. Lost Lanes can not have weapons deployed"+
			  "\nto them nor will have any more Titans spawning in them."+
			  "\nApproaching Titans: This is a queue of titans that are not yet added to"+
			  "\nany lane. However, it is used to decide which Titan types will be added to"+
			  "\nthe active lanes each turn. Whenever it is time to add a new Titan to an"+
			  "\nactive lane, the titan at the front of this approaching titans queue is"+
			  "\nremoved and then added to the intended lane. If the queue is empty while"+
			  "\nattempting to remove a titan, then the queue is refilled with multiple"+
			  "\ntitans according to the below table."+
			  "\nTitans Spawning & Battle Phase change: Each turn, A specific"+
			  "\nnumber of titans (Initially 1) is removed from the Approaching Titans"+
			  "\nand added to the lane with the least danger level. A Lane’s danger level is"+
			  "\nthe sum of all the titans’ danger levels inside this lane. If, while attempting"+
			  "\nto get an approaching titan, all of the approaching titans have been added"+
			  "\ninto lanes (Empty queue), the approaching titans will refill according to the"+
			  "\nfollowing table (If the battle phases has changed while some approaching"+
			  "\ntitans still remain, the approaching titans will not refill till all of them are"+
			  "\nadded to lanes and then refilled according to the battle phase at the"+
			  "\nmoment of refill). The table also shows how the battle phase and the"+
			  "\nnumber of titans to be added into the lanes change based on the elapsed"+
			  "number of turns."+
			  "\nWeapon Purchase: The player will have the option to see all the available"+
			  "\ntypes of weapons and can choose to buy and deploy them into their"+
			  "\nchoice of an active lane. To purchase a weapon, the player should have"+
			  "\nenough resources (higher than the weapon’s price) and then the weapon’s"+
			  "\nprice is deducted from the gathered resources."+
			  "\nTurn Actions: Each turn the player can choose to either Purchase and"+
			  "\nDeploy a Weapon or pass their turn without any actions. Either way the"+
			  "\nturn will proceed as follows. After the player’s action, The titans will do"+
			  "\ntheir move action. Then the weapons will do their attack action followed by"+
			  "\nthe titans’ attack actions. After that, Titans will be added to the lanes"+
			  "\naccording to the logic mentioned above. Finally, finalizing the turn by"+
			  "\nupdating the battle phase and the relevant info if needed based on the"+
			  "\nnumber of elapsed turns, also according to the logic mentioned above.";
  
	//start menu 
	   String buttonStyle = "-fx-background-color: transparent;";
	   String title= "-fx-font-family: goth; -fx-font-size:100;-fx-text-fill: white;";
	   String buttonHoveredStyle = "-fx-background-color: transparent; -fx-font-size: 60; -fx-text-fill: red;-fx-font-family: onyx;";
	   String desfont = "-fx-background-color: transparent; -fx-font-size: 20; -fx-text-fill: red;-fx-font-family: onyx;";
	   String buttonHoveredStyle2 = "-fx-background-color: black; -fx-font-size: 20; -fx-text-fill: red;-fx-font-family: onyx;";
	   String buttonHoveredStyleOrg = "-fx-background-color: transparent; -fx-font-size: 30; -fx-text-fill: white; -fx-font-family: onyx;";
	   String path= ("file:///Users/ahmed/Downloads/lastback.jpeg");
	 
	   Image backgroundImage = new Image(path);
	   ImageView myImage=new ImageView(backgroundImage);
	   Pane newroot = new Pane();
	   newroot.getChildren().add(myImage);
	   BackgroundImage background = new BackgroundImage(
	            backgroundImage,
	            BackgroundRepeat.NO_REPEAT,
	            BackgroundRepeat.NO_REPEAT,
	            BackgroundPosition.DEFAULT,
	            BackgroundSize.DEFAULT
	    );
	   Background backgroundStyle = new Background(background);

	
	primaryStage.setTitle("Attack On Titan Utopia");
	GridPane grid=new GridPane();
		
	Button Descrip=new Button("Game Description");
	Descrip.setStyle(buttonHoveredStyleOrg);
	Button ChangeDiff=new Button("Start");
	Label Title=new Label("Attack on Titan Utopia");
	Title.setStyle(title);
	
	ChangeDiff.setStyle(buttonHoveredStyleOrg);
	
	Descrip.setOnMouseEntered(new EventHandler<Event>(){

		@Override
		public void handle(Event event) {
			Descrip.setStyle(buttonHoveredStyle);
			
		}
		
	});
	Descrip.setOnMouseExited(new EventHandler<Event>(){

		@Override
		public void handle(Event event) {
			Descrip.setStyle(buttonHoveredStyleOrg);
			
		}
		
	});
	
	//change difficulty button
	
	ChangeDiff.setOnMouseEntered(new EventHandler<Event>(){

		@Override
		public void handle(Event event) {
			ChangeDiff.setStyle(buttonHoveredStyle);
			
		}
		
	});
	ChangeDiff.setOnMouseExited(new EventHandler<Event>(){

		@Override
		public void handle(Event event) {
			ChangeDiff.setStyle(buttonHoveredStyleOrg);
			
		}
		
	});
	
	
	
	
	
	
	
	
	grid.add(Title,2,0);
	
	grid.add(ChangeDiff,2,3);
	grid.add(Descrip, 2, 4);
	grid.prefWidthProperty().bind(primaryStage.widthProperty());
    grid.prefHeightProperty().bind(primaryStage.heightProperty());
    grid.setHgap(10);
    grid.setVgap(10);
    grid.setAlignment(Pos.CENTER);
    newroot.getChildren().add(grid);
    Scene scene= new Scene(newroot,1000,600);
    primaryStage.setScene(scene);
    primaryStage.show();
    

    
    
    
    
    
    
    
    
    
    
    
        
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    //difficulty screen
   String Desurlvid= "file:///Users/ahmed/Downloads/desVid.mp4";
    Media media2 = new Media(Desurlvid);
    MediaPlayer mediaPlayer2 = new MediaPlayer(media2);
    mediaPlayer2.setAutoPlay(true);
   MediaView mediaView2 = new MediaView(mediaPlayer2);
    mediaView2.fitWidthProperty().bind(primaryStage.widthProperty());
  mediaView2.fitHeightProperty().bind(primaryStage.heightProperty());
    
    BorderPane difficulty = new BorderPane();
    difficulty.setStyle("-fx-background-color: rgba(255, 255, 255, 0.5);"); 
    Button easy2 = new Button("Easy");
    Button hard2 = new Button("Hard");
    Button GameInstructions = new Button("Game Instructions");
  
    
  
   
    easy2.setStyle(buttonHoveredStyleOrg);
    hard2.setStyle(buttonHoveredStyleOrg);
    GameInstructions.setStyle(buttonHoveredStyleOrg);
   // gameInstructions.setAlignment(Pos.BOTTOM_RIGHT);
   // gameInstructions.setStyle("-fx-font-size: 15px;");
    //gameInstructions.setStyle(buttonHoveredStyleOrg);
    Label selectDifficulty = new Label("Select Difficulty");
    selectDifficulty.setStyle(buttonHoveredStyleOrg);
    
    
    HBox fBdiff = new HBox();
    fBdiff.setSpacing(10);
    fBdiff.getChildren().addAll(easy2, hard2 , GameInstructions);
    difficulty.setCenter(fBdiff);
    
    
    BorderPane.setAlignment(fBdiff, Pos.CENTER);
    difficulty.setTop(selectDifficulty);
    BorderPane.setAlignment(selectDifficulty, Pos.TOP_CENTER);
    StackPane root3 = new StackPane();
    
   root3.getChildren().add(mediaView2);
    root3.getChildren().add(difficulty);
    
    Scene Diff = new Scene(root3, 1000, 600);
   ChangeDiff.setOnMouseClicked(new EventHandler<Event>() {

	@Override
	public void handle(Event event) {
		primaryStage.setScene(Diff);
		primaryStage.show();
		primaryStage.setMaximized(true);
		
	}
	   
   });
   
   // el sa3a el fdya mtl3t4 fady    (ana t3bt)
   
   
    hard2.setOnMouseEntered(new EventHandler<Event>() {

			@Override
			public void handle(Event event) {
				hard2.setStyle(buttonHoveredStyle);
				
			}
			   
		   });
    hard2.setOnMouseExited(new EventHandler<Event>() {

		@Override
		public void handle(Event event) {
			hard2.setStyle(buttonHoveredStyleOrg);
			
		}
		   
	   });
    
    
    GameInstructions.setOnMouseEntered(new EventHandler<Event>() {

			@Override
			public void handle(Event event) {
				GameInstructions.setStyle(buttonHoveredStyle);
				
			}
			   
		   });
    GameInstructions.setOnMouseExited(new EventHandler<Event>() {

		@Override
		public void handle(Event event) {
			GameInstructions.setStyle(buttonHoveredStyleOrg);
			
		}
		   
	   });
    
    
    
    
    
    
    
    
    
    
    
    
    
   
  
   


   
   
   
   
   
   
   
   
   
   
   
   
   
   //descripton scene
   
   
   
   
   
  

	
   String videoUrl = "file:///Users//ahmed//Downloads//vid.mp4";
   Media media = new Media(videoUrl);

   // Create a MediaPlayer with the video
   MediaPlayer mediaPlayer = new MediaPlayer(media);
   mediaPlayer.setAutoPlay(true); // Auto play the video

   // Create a MediaView to display the video
   MediaView mediaView = new MediaView(mediaPlayer);

   // Set the size of the MediaView to cover the entire scene
   mediaView.fitWidthProperty().bind(primaryStage.widthProperty());
   mediaView.fitHeightProperty().bind(primaryStage.heightProperty());

   // Create the description pane
   BorderPane descriptionPane = new BorderPane();
   descriptionPane.setStyle("-fx-background-color: rgba(255, 255, 255, 0.5);"); // Semi-transparent white background
   Label descriptionLabel = new Label("Attack on Titan: Utopia is a one-player, endless 2 , tower defense game 1\n"
   		+ "inspired by the hit anime Attack on Titan. The story of the anime\n"
   		+ "revolves around how titans, gigantic humanoid creatures, emerged one day\n"
   		+ "and wiped out most of humanity. The few surviving humans fled and hid\n"
   		+ "behind 3 great walls that provided safe haven from the titan threats. Wall\n"
   		+ "Maria is the outer wall, Wall Rose is the middle wall and Wall Sina is the\n"
   		+ "inside wall.\n"
   		+ "This game takes place in an imaginary scenario where the titans breached\n"
   		+ "their way throughout Wall Maria and reached the northern border of Wall\n"
   		+ "Rose at the Utopia District. The human forces stationed in Utopia engage\n"
   		+ "the titans in battle for one last hope of preventing the titans from\n"
   		+ "breaching Wall Rose. The humans fight by deploying different types of\n"
   		+ "Anti-Titan weapons in order to stop the Titan’s onslaught and keep Utopia’s\n"
   		+ "(and Wall Rose’s) walls safe.");
   descriptionLabel.setStyle(desfont);
   Button returnMain=new Button("Return");
   
   descriptionPane.setBottom(returnMain);
   BorderPane.setAlignment(returnMain, Pos.BOTTOM_LEFT);
   descriptionPane.setCenter(descriptionLabel);
   BorderPane.setAlignment(descriptionLabel, Pos.CENTER);

   // StackPane to layer background (video) and foreground (description)
   StackPane root2 = new StackPane();
   // Add the MediaView (video background) to the bottom of the stack pane
   root2.getChildren().add(mediaView);
   // Add the description pane on top of the video
   root2.getChildren().add(descriptionPane);

   // Create the scene and set the root node
   Scene scene2 = new Scene(root2, 1000, 600);
  Descrip.setOnMouseClicked(new EventHandler<Event>() {

	@Override
	public void handle(Event event) {
		primaryStage.setScene(scene2);
		primaryStage.show();
		primaryStage.setMaximized(true);
		
	}
	  
  });
  returnMain.setOnMouseClicked(new EventHandler<Event>() {

	@Override
	public void handle(Event arg0) {
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setMaximized(true);
		
	}
	  
  });

	   
  ToggleGroup toggleGroup = new ToggleGroup();
	//first lane button
	RadioButton firstLane = new  RadioButton("Lane 1");
	firstLane.setToggleGroup(toggleGroup);
	
	//second lane button
	RadioButton secondLane = new RadioButton("Lane 2");
	secondLane.setToggleGroup(toggleGroup);
	
	//third lane button
	RadioButton thirdLane = new RadioButton("Lane 3");
	thirdLane.setToggleGroup(toggleGroup);
	
	//hbox to insert the buttons
	HBox radioB = new HBox();
	//adding the buttons to the hbox
	radioB.getChildren().addAll(firstLane , secondLane , thirdLane);
	radioB.setAlignment(Pos.TOP_CENTER);
	
	//making a border pane to add the hbox to it
	BorderPane root = new BorderPane();
	//putting the buttons hbox in top centre
	BorderPane.setAlignment(radioB, Pos.TOP_CENTER);
	
	 root.setTop(radioB);//putting the radioButtons in the root to create scene
	 //VBox weapons = new VBox();
	 
	 
	 //left vertical box
	 //the label to add the weapon name
	 easy2.setOnMouseClicked(new EventHandler<Event>() {
        
		@Override
		public void handle(Event event) {
			try {
				gameEasy();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		   
		   String urlWalls =("file:///Users//ahmed//Downloads//wall.jpeg");
		   String gameImage="file:///Users//ahmed//Downloads//mainGame.png";
		   Image gameImage2=new Image(gameImage);
		 
		   ImageView gameview=new ImageView(gameImage);
		   BackgroundSize backgroundSize = new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, true);
		   BackgroundImage background2 = new BackgroundImage(
		            gameImage2,
		            BackgroundRepeat.NO_REPEAT,
		            BackgroundRepeat.NO_REPEAT,
		            BackgroundPosition.DEFAULT,
		            backgroundSize
		    );
		   Background backgroundStyle1 = new Background(background2);
		   
		   
		   
		   Image wall=new Image(urlWalls);
		   ImageView wallview1=new ImageView(wall);
		   ImageView wallview2=new ImageView(wall);
		   ImageView wallview3=new ImageView(wall);
		   /*
		    * VBox wallS = new VBox();
				// Adjust spacing between wallss
				Pane wallPane1 = new Pane();
				Pane wallPane2 = new Pane();
				Pane wallPane3 = new Pane();
				Pane wallPane4 = new Pane();
				Pane wallPane5= new Pane();
				ImageView wallView1= new ImageView(new Image("file:///Users/ahmed/Downloads/wall.jpeg"));
				wallView1.setFitWidth(200); // Set the desired width
				wallView1.setFitHeight(200);
				ImageView wallView2 = new ImageView(new Image("file:///Users/ahmed/Downloads/wall.jpeg"));
				wallView2.setFitWidth(200); // Set the desired width
				wallView2.setFitHeight(200);
				ImageView wallView3 = new ImageView(new Image("file:///Users/ahmed/Downloads/wall.jpeg"));
				wallView3.setFitWidth(200); // Set the desired width
				wallView3.setFitHeight(200);
				ImageView wallView4 = new ImageView(new Image("file:///Users/ahmed/Downloads/wall.jpeg"));
				wallView4.setFitWidth(200); // Set the desired width
				wallView4.setFitHeight(200);
				ImageView wallView5 = new ImageView(new Image("file:///Users/ahmed/Downloads/wall.jpeg"));
				wallView5.setFitWidth(200); // Set the desired width
				wallView5.setFitHeight(200);
				wallPane1.getChildren().add(wallView1);
				wallPane2.getChildren().add(wallView2);
				wallPane3.getChildren().add(wallView3);
				wallPane4.getChildren().add(wallView4);
				wallPane5.getChildren().add(wallView5);
				VBox weaponS = new VBox();
				weaponS.setSpacing(20); 
				Pane weaponPane1 = new Pane();
				Pane weaponPane2 = new Pane();
				Pane weaponPane3 = new Pane();
				Pane weaponPane4 = new Pane();
				Pane weaponPane5 = new Pane();
				Label health1=new Label("Health dl");
				Label health2=new Label("Health dl");
				Label health3=new Label("Health dl");
				Label health4=new Label("Health dl");
				Label health5=new Label("Health dl");
				HBox healthDl1=new HBox();
				HBox healthDl2=new HBox();
				HBox healthDl3=new HBox();
				HBox healthDl4=new HBox();
				HBox healthDl5=new HBox();
				healthDl1.getChildren().addAll(wallPane1,health1);
				healthDl2.getChildren().addAll(wallPane2,health2);
				healthDl3.getChildren().addAll(wallPane3,health3);
				healthDl4.getChildren().addAll(wallPane4,health4);
				healthDl5.getChildren().addAll(wallPane5,health5);
				TextArea weaponPaneTxt1=new TextArea("");
				TextArea weaponPaneTxt2=new TextArea("");
				TextArea weaponPaneTxt3=new TextArea("");
				TextArea weaponPaneTxt4=new TextArea("");
				TextArea weaponPaneTxt5=new TextArea("");
				weaponPaneTxt1.setEditable(false);
				weaponPaneTxt2.setEditable(false);
				weaponPaneTxt3.setEditable(false);
				weaponPaneTxt4.setEditable(false);
				weaponPaneTxt5.setEditable(false);
				weaponPane1.getChildren().add(weaponPaneTxt1);
				weaponPane2.getChildren().add(weaponPaneTxt2);
				weaponPane3.getChildren().add(weaponPaneTxt3);
				weaponPane4.getChildren().add(weaponPaneTxt4);
				weaponPane5.getChildren().add(weaponPaneTxt5);
				weaponS.getChildren().addAll(weaponPane1,weaponPane2,weaponPane3,weaponPane4,weaponPane5);
				wallS.getChildren().addAll(healthDl1,healthDl2,healthDl3,healthDl4,healthDl5);
				lanez.setSpacing(20);
				wallS.setSpacing(20);
				lanez.setAlignment(Pos.CENTER);
				wallS.setAlignment(Pos.CENTER);
				// Set alignment of lanes, walls, and weapons to center
				HBox centerBox = new HBox();
				centerBox.setAlignment(Pos.CENTER); // Align elements to the center
				centerBox.setSpacing(20); // Adjust spacing between elements

				// Add the lanes, walls, and weapons to the center HBox
				centerBox.setSpacing(20);
				centerBox.getChildren().addAll(weaponS, wallS, lanez);
		    */
		  
		   BorderPane main=new BorderPane();
		   VBox walls=new VBox();
		   Pane wPe1 = new Pane();
			Pane wPe2 = new Pane();
			Pane wPe3 = new Pane();
			Image walll1=new Image(urlWalls);
			ImageView wallView1E= new ImageView(walll1);
			wallView1E.setFitWidth(200); // Set the desired width
			wallView1E.setFitHeight(200);
			Image walll2=new Image(urlWalls);
			ImageView wallView2E = new ImageView(walll2);
			wallView2E.setFitWidth(200); // Set the desired width
			wallView2E.setFitHeight(200);
			Image walll3=new Image(urlWalls);
			ImageView wallView3E = new ImageView(walll3);
			wallView3E.setFitWidth(200); // Set the desired width
			wallView3E.setFitHeight(200);
			wPe1.getChildren().add(wallView1E);
			wPe2.getChildren().add(wallView2E);
			wPe3.getChildren().add(wallView3E);
			Label health1E=new Label("Health dlE");
			Label health2E=new Label("Health dlE");
			Label health3E=new Label("Health dlE");
			
			
			HBox healthDl1E=new HBox();
			HBox healthDl2E=new HBox();
			HBox healthDl3E=new HBox();
			
			healthDl1E.getChildren().addAll(health1E,wPe1);
			healthDl2E.getChildren().addAll(health2E,wPe2);
			healthDl3E.getChildren().addAll(health3E,wPe3);
			walls.getChildren().addAll(healthDl1E,healthDl2E,healthDl3E);
			walls.setSpacing(20);
			VBox titandetailsE=new VBox();
			titandetailsE.setMaxWidth(100);
			TextArea titan1E=new TextArea("");
			TextArea titan2E=new TextArea("");
			TextArea titan3E=new TextArea("");
			titan1E.setEditable(false);
			titan2E.setEditable(false);
			titan3E.setEditable(false);
			titandetailsE.getChildren().addAll(titan1E,titan2E,titan3E);
			
		   HBox finaly=new HBox();
		   VBox weapons=new VBox();
		  weapons.setMaxWidth(50);
		   VBox lanes=new VBox();
		   lanes.setPrefWidth(currentLane);
		   Pane weapon1=new Pane();
		   Pane weapon2=new Pane();
		   Pane weapon3=new Pane();
		   TextArea l1=new TextArea("");
		   l1.setMaxWidth(40);
		   TextArea l2=new TextArea("");
		   l2.setMaxWidth(40);
		   TextArea l3=new TextArea("");
		   l3.setMaxWidth(40);
		   l1.setEditable(false);
		   l2.setEditable(false);
		   l3.setEditable(false);
		   weapon1.getChildren().add(l1);
		   weapon2.getChildren().add(l2);
		   weapon3.getChildren().add(l3);
		   weapons.getChildren().addAll(weapon1,weapon2,weapon3);
		  /* Pane wall1=new Pane();
		   Pane wall2=new Pane();
		   Pane wall3=new Pane();
		   wall1.getChildren().add(wallview1);
		   wall2.getChildren().add(wallview2);
		   wall3.getChildren().add(wallview3);
		   walls.getChildren().addAll(wall1,wall2,wall3);*/
		   Pane lane1=new Pane();
		   Pane lane2=new Pane();
		   Pane lane3=new Pane();
		   lane1.setPrefWidth(600);
		   lane2.setPrefWidth(600);
		   lane3.setPrefWidth(600);
		   lane1.setMaxHeight(200);
		   lane2.setMaxHeight(200);
		   lane3.setMaxHeight(200);
		   lanes.setSpacing(30);
		   lanes.getChildren().addAll(lane1,lane2,lane3);
		   lanes.setAlignment(Pos.BASELINE_LEFT);
		   finaly.getChildren().addAll(weapons,titandetailsE,walls,lanes);
		   finaly.setSpacing(20);
		   finaly.setAlignment(Pos.CENTER_LEFT);
		   main.setCenter(finaly);
		   Label round=new Label("Round:");
		   round.setStyle(buttonHoveredStyleOrg);
		   
		   Label roundnum=new Label("1");
		  roundnum.setStyle(buttonHoveredStyleOrg);
		   Label score=new Label("Score:");
		   score.setStyle(buttonHoveredStyleOrg);
		   Label scoreA=new Label("0");
		   scoreA.setStyle(buttonHoveredStyleOrg);
		   HBox rounds=new HBox();
		   rounds.getChildren().addAll(round,roundnum,score, scoreA);
		   main.setTop(rounds);
		   BorderPane sub=new BorderPane();
		   VBox subtext=new VBox();
		   HBox currentres=new HBox();
		   Label res=new Label("Available resources");
		   res.setStyle(buttonHoveredStyle2);
		   Label resA=new Label("750");
		   resA.setStyle(buttonHoveredStyle2);
		   currentres.getChildren().addAll(res,resA);
		  subtext.getChildren().add(currentres);
		  HBox phase=new HBox();
		  Label currentPhase=new Label("Phase:");
		  currentPhase.setStyle(buttonHoveredStyle2);
		  Label currentPhaseA=new Label("Early");
		  currentPhaseA.setStyle(buttonHoveredStyle2);
		  phase.getChildren().addAll(currentPhase,currentPhaseA);
		   subtext.getChildren().add(phase);
		   sub.setCenter(subtext);
		   HBox buttonsM=new HBox();
		   Button purchase=new Button("Purchase Weapon");
		   Button pass=new Button("Pass Turn");
		   Button AI=new Button("best action for player");
		   AI.setStyle(buttonHoveredStyle2);
		   pass.setOnMouseClicked(new EventHandler<Event>() {
			  
				public void gameOver() {
				  if(battle.getOriginalLanes().get(0).isLaneLost()&&battle.getOriginalLanes().get(1).isLaneLost()&&battle.getOriginalLanes().get(2).isLaneLost()) {
					  displayAlert("Game Over","all lanes are lost return to start menu");
				  primaryStage.close();
				  primaryStage.setScene(scene);
				  primaryStage.show();
				  primaryStage.setMaximized(true);}
			  }
			
			   public void addTitans() {
				    ArrayList<ImageView> LANE1=new ArrayList<ImageView>();
				    ArrayList<ImageView> LANE2=new ArrayList<ImageView>();
				    ArrayList<ImageView> LANE3=new ArrayList<ImageView>();
				   
					for(Lane lane:battle.getOriginalLanes()) {
			    	for(Titan titan:lane.getTitans()) {
			    		if(battle.getOriginalLanes().indexOf(lane)==0) {
			    		if(titan instanceof PureTitan)
			    			{
			    			ImageView bi=getPureTitanImage();
			    			LANE1.add(bi);
			    			lane1.getChildren().add(bi);
			    			bi.setTranslateX(titan.getDistance()*10);
			    			}
			    		else if(titan instanceof ColossalTitan) {
			    			ImageView bi=getCollosalTitanImage();
			    			LANE1.add(bi);
			    			lane1.getChildren().add(bi);
			    			bi.setTranslateX(titan.getDistance()*10);
			    			}
			    		else if(titan instanceof AbnormalTitan) {
			    			
			    			ImageView bi=getAbnormalTitanImage();
			    			LANE1.add(bi);
			    			lane1.getChildren().add(bi);
			    			bi.setTranslateX(titan.getDistance()*10);}
			    		else { 
			    			ImageView bi=getArmoredTitanImage();
			    			LANE1.add(bi);
			    			lane1.getChildren().add(bi);
			    			bi.setTranslateX(titan.getDistance()*10);
			    			}
			    		}
			    		if(battle.getOriginalLanes().indexOf(lane)==1) {
			    			if(titan instanceof PureTitan)
			    			{
			    			ImageView bi=getPureTitanImage();
			    			LANE2.add(bi);
			    			lane2.getChildren().add(bi);
			    			bi.setTranslateX(titan.getDistance()*10);
			    			}
			    		else if(titan instanceof ColossalTitan) {
			    			ImageView bi=getCollosalTitanImage();
			    			LANE2.add(bi);
			    			lane2.getChildren().add(bi);
			    			bi.setTranslateX(titan.getDistance()*10);			    			}
			    		else if(titan instanceof AbnormalTitan) {
			    			
			    			ImageView bi=getAbnormalTitanImage();
			    			LANE2.add(bi);
			    			lane2.getChildren().add(bi);
			    			bi.setTranslateX(titan.getDistance()*10);
			    			}
			    		else { 
			    			ImageView bi=getArmoredTitanImage();
			    			LANE2.add(bi);
			    			lane2.getChildren().add(bi);
			    			bi.setTranslateX(titan.getDistance()*10);
			    			}
			    		}
			    		
			    		if(battle.getOriginalLanes().indexOf(lane)==2) {
				    		if(titan instanceof PureTitan) {
				    			ImageView bi=getPureTitanImage();
				    			LANE3.add(bi);
				    			lane3.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);}
				    		else if(titan instanceof ColossalTitan) {
				    			ImageView bi=getCollosalTitanImage();
				    			LANE3.add(bi);
				    			lane3.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);}
				    		else if(titan instanceof AbnormalTitan) {
				    			ImageView bi=getAbnormalTitanImage();
				    			LANE3.add(bi);
				    			lane3.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);}
				    		else {
				    			ImageView bi=getArmoredTitanImage();
				    			LANE3.add(bi);
				    			lane3.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);}}
			    		
			    		
			    				
			    		}
			  
					}	
					
			    	
		   }
			 //add void update resources and update score 
			 /////////////////////////////////////////////////////////
			 public void updatePhase() {
				 String res=""+battle.getBattlePhase();
				 currentPhaseA.setText(res);
			 }  
			 public void updateHealthAndDangerLevel(){	
				 health1E.setText(updateWall1Health() + "\n" +updatelane1Dl() );
				 health2E.setText(updateWall2Health() + "\n" + updatelane2Dl());
				 health3E.setText(updateWall2Health()+ "\n" +updatelane3Dl());
			 }
			
			 
			 public void updateRound() {
				 int a=battle.getNumberOfTurns();
				 String resAA=""+a;
				 roundnum.setText(resAA);
			 }
			 public void updateScore() {
				 int a=battle.getScore();
				 String resAA=""+a;
				 scoreA.setText(resAA);
			 }
			 
			 public void updateLane() {
				 if(battle.getOriginalLanes().get(0).isLaneLost()) {
					 displayAlert("lane lost", "lane 1's wall has been breached");
					 health1E.setText("lane lost");}
				 if(battle.getOriginalLanes().get(1).isLaneLost()) {
					 displayAlert("lane lost", "lane 2's wall has been breached");
					 health2E.setText("lane lost");}
				 if(battle.getOriginalLanes().get(2).isLaneLost()) {
					 displayAlert("lane lost", "lane 3's wall has been breached");
					 health3E.setText("lane lost");}}
			 public void updateTitans() {
				 titan1E.clear();
				 titan2E.clear();
				 titan3E.clear();
				 for(Titan t:battle.getOriginalLanes().get(0).getTitans()) {
					 String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
					  titan1E.appendText(res);
				 }
				 for(Titan t:battle.getOriginalLanes().get(1).getTitans()) {
					 String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
					  titan2E.appendText(res);
				 }
				 for(Titan t:battle.getOriginalLanes().get(2).getTitans()) {
					 String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
					  titan3E.appendText(res);
				 }
				 
			 }
			public void handle(Event arg0) {
				
				battle.passTurn();
				 lane1.getChildren().clear();
				 lane2.getChildren().clear();
				 lane3.getChildren().clear();
				updateHealthAndDangerLevel();
				
				addTitans();
				updateTitans();
				updateScore();
				updateRound();
				updateLane();
				
				 updatePhase();
				 gameOver();
			}
			   
		   });
		   AI.setOnMouseClicked(new EventHandler<Event>() {
           public int random() {
        	   int res= (int)(Math.random()*3+1);
        	   return res;
           }
       	public void gameOver() {
			  if(battle.getOriginalLanes().get(0).isLaneLost()&&battle.getOriginalLanes().get(1).isLaneLost()&&battle.getOriginalLanes().get(2).isLaneLost()) {
				  displayAlert("Game Over","all lanes are lost return to start menu");
			  primaryStage.close();
			  primaryStage.setScene(scene);
			  primaryStage.show();
			  primaryStage.setMaximized(true);}
		  }
		
		   public void addTitans() {
			    ArrayList<ImageView> LANE1=new ArrayList<ImageView>();
			    ArrayList<ImageView> LANE2=new ArrayList<ImageView>();
			    ArrayList<ImageView> LANE3=new ArrayList<ImageView>();
			   
				for(Lane lane:battle.getOriginalLanes()) {
		    	for(Titan titan:lane.getTitans()) {
		    		if(battle.getOriginalLanes().indexOf(lane)==0) {
		    		if(titan instanceof PureTitan)
		    			{
		    			ImageView bi=getPureTitanImage();
		    			LANE1.add(bi);
		    			lane1.getChildren().add(bi);
		    			bi.setTranslateX(titan.getDistance()*10);
		    			}
		    		else if(titan instanceof ColossalTitan) {
		    			ImageView bi=getCollosalTitanImage();
		    			LANE1.add(bi);
		    			lane1.getChildren().add(bi);
		    			bi.setTranslateX(titan.getDistance()*10);
		    			}
		    		else if(titan instanceof AbnormalTitan) {
		    			
		    			ImageView bi=getAbnormalTitanImage();
		    			LANE1.add(bi);
		    			lane1.getChildren().add(bi);
		    			bi.setTranslateX(titan.getDistance()*10);}
		    		else { 
		    			ImageView bi=getArmoredTitanImage();
		    			LANE1.add(bi);
		    			lane1.getChildren().add(bi);
		    			bi.setTranslateX(titan.getDistance()*10);
		    			}
		    		}
		    		if(battle.getOriginalLanes().indexOf(lane)==1) {
		    			if(titan instanceof PureTitan)
		    			{
		    			ImageView bi=getPureTitanImage();
		    			LANE2.add(bi);
		    			lane2.getChildren().add(bi);
		    			bi.setTranslateX(titan.getDistance()*10);
		    			}
		    		else if(titan instanceof ColossalTitan) {
		    			ImageView bi=getCollosalTitanImage();
		    			LANE2.add(bi);
		    			lane2.getChildren().add(bi);
		    			bi.setTranslateX(titan.getDistance()*10);			    			}
		    		else if(titan instanceof AbnormalTitan) {
		    			
		    			ImageView bi=getAbnormalTitanImage();
		    			LANE2.add(bi);
		    			lane2.getChildren().add(bi);
		    			bi.setTranslateX(titan.getDistance()*10);
		    			}
		    		else { 
		    			ImageView bi=getArmoredTitanImage();
		    			LANE2.add(bi);
		    			lane2.getChildren().add(bi);
		    			bi.setTranslateX(titan.getDistance()*10);
		    			}
		    		}
		    		
		    		if(battle.getOriginalLanes().indexOf(lane)==2) {
			    		if(titan instanceof PureTitan) {
			    			ImageView bi=getPureTitanImage();
			    			LANE3.add(bi);
			    			lane3.getChildren().add(bi);
			    			bi.setTranslateX(titan.getDistance()*10);}
			    		else if(titan instanceof ColossalTitan) {
			    			ImageView bi=getCollosalTitanImage();
			    			LANE3.add(bi);
			    			lane3.getChildren().add(bi);
			    			bi.setTranslateX(titan.getDistance()*10);}
			    		else if(titan instanceof AbnormalTitan) {
			    			ImageView bi=getAbnormalTitanImage();
			    			LANE3.add(bi);
			    			lane3.getChildren().add(bi);
			    			bi.setTranslateX(titan.getDistance()*10);}
			    		else {
			    			ImageView bi=getArmoredTitanImage();
			    			LANE3.add(bi);
			    			lane3.getChildren().add(bi);
			    			bi.setTranslateX(titan.getDistance()*10);}}
		    		
		    		
		    				
		    		}
		  
				}	
				
		    	
	   }
		 //add void update resources and update score 
		 /////////////////////////////////////////////////////////
		 public void updatePhase() {
			 String res=""+battle.getBattlePhase();
			 currentPhaseA.setText(res);
		 }  
		 public void updateHealthAndDangerLevel(){	
			 health1E.setText(updateWall1Health() + "\n" +updatelane1Dl() );
			 health2E.setText(updateWall2Health() + "\n" + updatelane2Dl());
			 health3E.setText(updateWall2Health()+ "\n" +updatelane3Dl());
		 }
		
		 
		 public void updateRound() {
			 int a=battle.getNumberOfTurns();
			 String resAA=""+a;
			 roundnum.setText(resAA);
		 }
		 public void updateScore() {
			 int a=battle.getScore();
			 String resAA=""+a;
			 scoreA.setText(resAA);
		 }
		 
		 public void updateLane() {
			 if(battle.getOriginalLanes().get(0).isLaneLost()) {
				 displayAlert("lane lost", "lane 1's wall has been breached");
				 health1E.setText("lane lost");}
			 if(battle.getOriginalLanes().get(1).isLaneLost()) {
				 displayAlert("lane lost", "lane 2's wall has been breached");
				 health2E.setText("lane lost");}
			 if(battle.getOriginalLanes().get(2).isLaneLost()) {
				 displayAlert("lane lost", "lane 3's wall has been breached");
				 health3E.setText("lane lost");}}
		 public void updateTitans() {
			 titan1E.clear();
			 titan2E.clear();
			 titan3E.clear();
			 for(Titan t:battle.getOriginalLanes().get(0).getTitans()) {
				 String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
				  titan1E.appendText(res);
			 }
			 for(Titan t:battle.getOriginalLanes().get(1).getTitans()) {
				 String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
				  titan2E.appendText(res);
			 }
			 for(Titan t:battle.getOriginalLanes().get(2).getTitans()) {
				 String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
				  titan3E.appendText(res);
			 }
			 
		 }
			@Override
			public void handle(Event arg0) {
				try {
					if(battle.getOriginalLanes().get(currentLane).isLaneLost()) {
						throw new InvalidLaneException();
					}
					if(battle.getResourcesGathered()>=100) {
						int r=random();
					battle.purchaseWeapon(3, battle.getOriginalLanes().get(r));
					switch(r) {
					case 1:
					l1.appendText(battle.getWeaponFactory().getWeaponShop().get(3).getName()+"\n");break;
					case 2:
						l2.appendText(battle.getWeaponFactory().getWeaponShop().get(3).getName()+"\n"); break;
					default: l3.appendText(battle.getWeaponFactory().getWeaponShop().get(3).getName()+"\n");break; }
					}
					else if(battle.getResourcesGathered()<100 && battle.getResourcesGathered()>=75) {
						int r=random();								
						battle.purchaseWeapon(4, battle.getOriginalLanes().get(r));
						switch(r) {
						case 1:
						    l1.appendText(battle.getWeaponFactory().getWeaponShop().get(1).getName()+"\n"); break;
						case 2:
							l2.appendText(battle.getWeaponFactory().getWeaponShop().get(1).getName()+"\n "); break;
						default:
							l3.appendText(battle.getWeaponFactory().getWeaponShop().get(1).getName()+"\n "); break;
						}
					}
					else if(battle.getResourcesGathered()<75 && battle.getResourcesGathered()>=25) {
						int r=random();
						battle.purchaseWeapon(2, battle.getOriginalLanes().get(r));
						switch(r) {
						case 1:l1.appendText(battle.getWeaponFactory().getWeaponShop().get(2).getName()+"\n  "); break;
						case 2: l2.appendText(battle.getWeaponFactory().getWeaponShop().get(2).getName()+" \n "); break;
						default:l3.appendText(battle.getWeaponFactory().getWeaponShop().get(1).getName()+"\n  "); break;
						}
					}
					else  {
						battle.passTurn();}
				}catch(InsufficientResourcesException e) {
					displayAlert("InssufficientResources","enta mfls");
				} catch (InvalidLaneException e) {
					displayAlert("InvalidLaneException","el lane day3 ");}
				lane1.getChildren().clear();
				lane2.getChildren().clear();
				lane3.getChildren().clear();
				updateHealthAndDangerLevel();				
				addTitans();
				updateTitans();
				updateScore();
				updateRound();
				updateLane();
				gameOver();
				 updatePhase();
				 
			}
			   
		   });
		   
		   purchase.setStyle(buttonHoveredStyleOrg);
		   pass.setStyle(buttonHoveredStyleOrg);
		   buttonsM.getChildren().addAll(purchase,pass,AI);
		   sub.setBottom(buttonsM);
		   main.setBottom(sub);
		   main.setBackground(backgroundStyle1);
		   Scene mainView=new Scene(main,1000,600);
			primaryStage.setScene(mainView);
			primaryStage.show();
			primaryStage.setMaximized(true);
			
			String left1=("Name: "+battle.getWeaponFactory().getWeaponShop().get(1).getName()+
					 "\nPrice: "+battle.getWeaponFactory().getWeaponShop().get(1).getPrice()+
					 "\nDamage: "+battle.getWeaponFactory().getWeaponShop().get(1).getDamage()+
					 "\nType: PiercingCannon");
			 String left2=("Name: "+battle.getWeaponFactory().getWeaponShop().get(2).getName()+
					 "\nPrice: "+battle.getWeaponFactory().getWeaponShop().get(2).getPrice()+
					 "\nDamage: "+battle.getWeaponFactory().getWeaponShop().get(2).getDamage()+
					 "\nType: SniperCannon");
			 String right1=("Name: "+battle.getWeaponFactory().getWeaponShop().get(3).getName()+
					 "\nPrice: "+battle.getWeaponFactory().getWeaponShop().get(3).getPrice()+
					 "\nDamage: "+battle.getWeaponFactory().getWeaponShop().get(3).getDamage()+
					 "\nType: VolleySpread");
			 String right2=("Name: "+battle.getWeaponFactory().getWeaponShop().get(4).getName()+
					 "\nPrice: "+battle.getWeaponFactory().getWeaponShop().get(4).getPrice()+
					 "\nDamage: "+battle.getWeaponFactory().getWeaponShop().get(4).getDamage()+
					 "\nType: WallTrap");
			 TextArea leftWeaponName1 = new TextArea(left1);
			 TextArea leftWeaponName2 = new TextArea(left2);
			 
			 ImageView imageView1 = new ImageView("file:///Users//ahmed//Downloads/piercing cannon.jpeg");
			 ImageView imageView2 = new ImageView("file:///Users//ahmed//Downloads//sniper.jpeg");
			 imageView1.setFitWidth(300); // Adjust width as needed
		   imageView1.setFitHeight(300); // Adjust height as needed
		   imageView2.setFitWidth(300); // Adjust width as needed
		   imageView2.setFitHeight(300); // Adjust height as needed
		   
		   
			 //the button to buy the weapon
			 Button addWeapon1 = new Button("Add weapon 1");
			 Button addWeapon2 = new Button("Add weapon 2");
			 
			 //create a vbox to insert the image , the name and button
			 VBox wweapons = new VBox();
			  wweapons.setSpacing(10);
			 //putting all elements in the vbox
			 wweapons.getChildren().addAll(imageView1, leftWeaponName1, addWeapon1 ,imageView2, leftWeaponName2, addWeapon2);
			 //aligning the elements to the left centre
			 BorderPane.setAlignment(wweapons, Pos.CENTER_LEFT);
			 BorderPane.setMargin(wweapons, new Insets(50, 0, 0, 180));
			 root.setCenter(wweapons);
			 
			
			 
			 
			 TextArea rightWeaponName3 = new TextArea(right1);
			 TextArea rightWeaponName4 = new TextArea(right2);
			 //image path
			 ImageView imageView3 = new ImageView("file:///Users//ahmed//Downloads//volleyspread.jpeg");
			 ImageView imageView4 = new ImageView("file:///Users//ahmed//Downloads//walltrap.jpeg");
			 imageView3.setFitWidth(300); // Adjust width as needed
		   imageView3.setFitHeight(300); // Adjust height as needed
		   imageView4.setFitWidth(300); // Adjust width as needed
		   imageView4.setFitHeight(300); // Adjust height as needed
		   
		   
			 //the button to buy the weapon
			 Button addWeapon3 = new Button("Add weapon 3");
			 Button addWeapon4 = new Button("Add weapon 4");
			 
			 //create a vbox to insert the image , the name and button
			 VBox weaponsRight = new VBox();
			  weaponsRight.setSpacing(10);
			 //putting all elements in the vbox
			 weaponsRight.getChildren().addAll(imageView3, rightWeaponName3, addWeapon3 ,imageView4, rightWeaponName4, addWeapon4);
			 //aligning the elements to the left centre
			 BorderPane.setAlignment(weaponsRight, Pos.CENTER_RIGHT);
			 BorderPane.setMargin(weaponsRight, new Insets(50, 180, 0, 0));
			 root.setRight(weaponsRight);
			 Button returnGame=new Button("Return");
			 returnGame.setStyle(buttonHoveredStyleOrg);
			 root.setBottom(returnGame);
			 BorderPane.setAlignment(returnGame, Pos.BOTTOM_LEFT);

			 Scene shopscene = new Scene(root, 1000, 600);
			 
			
			 firstLane.setOnMouseClicked(new EventHandler<Event>() {

				@Override
				public void handle(Event event) {
					currentLane =0;
					
				}
				 
			 });
			 secondLane.setOnMouseClicked(new EventHandler<Event>() {

					@Override
					public void handle(Event event) {
						currentLane =1;
						
					}
					 
				 });
			 thirdLane.setOnMouseClicked(new EventHandler<Event>() {

					@Override
					public void handle(Event event) {
						currentLane =2;
						
					}
					 
				 });
			 
			 purchase.setOnMouseClicked(new EventHandler<Event>() {

				@Override
				public void handle(Event arg0) {
					primaryStage.setScene(shopscene);
					primaryStage.show();
					primaryStage.setMaximized(true);
					
				}
				 
			 });
			 
			 returnGame.setOnMouseClicked(new EventHandler<Event>() {
				
		         
				@Override
				public void handle(Event arg0) {
					
					primaryStage.setScene(mainView);
					primaryStage.show();
					primaryStage.setMaximized(true);
					
				}
				 
			 });
		
			

			   
			 addWeapon1.setOnMouseClicked(new EventHandler<Event>() {
				 public void gameOver() {
					  if(battle.getOriginalLanes().get(0).isLaneLost()&&battle.getOriginalLanes().get(1).isLaneLost()&&battle.getOriginalLanes().get(2).isLaneLost())
					  {  displayAlert("Game Over","all lanes are lost return to start menu");
					  
					  primaryStage.close();
					  primaryStage.setScene(scene);
					  primaryStage.show();
					  primaryStage.setMaximized(true);}
				  }
				 public void addTitans() {
					    ArrayList<ImageView> LANE1=new ArrayList<ImageView>();
					    ArrayList<ImageView> LANE2=new ArrayList<ImageView>();
					    ArrayList<ImageView> LANE3=new ArrayList<ImageView>();
					   
						for(Lane lane:battle.getOriginalLanes()) {
				    	for(Titan titan:lane.getTitans()) {
				    		if(battle.getOriginalLanes().indexOf(lane)==0) {
				    		if(titan instanceof PureTitan)
				    			{
				    			ImageView bi=getPureTitanImage();
				    			LANE1.add(bi);
				    			lane1.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		else if(titan instanceof ColossalTitan) {
				    			ImageView bi=getCollosalTitanImage();
				    			LANE1.add(bi);
				    			lane1.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		else if(titan instanceof AbnormalTitan) {
				    			
				    			ImageView bi=getAbnormalTitanImage();
				    			LANE1.add(bi);
				    			lane1.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);}
				    		else { 
				    			ImageView bi=getArmoredTitanImage();
				    			LANE1.add(bi);
				    			lane1.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		}
				    		if(battle.getOriginalLanes().indexOf(lane)==1) {
				    			if(titan instanceof PureTitan)
				    			{
				    			ImageView bi=getPureTitanImage();
				    			LANE2.add(bi);
				    			lane2.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		else if(titan instanceof ColossalTitan) {
				    			ImageView bi=getCollosalTitanImage();
				    			LANE2.add(bi);
				    			lane2.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);			    			}
				    		else if(titan instanceof AbnormalTitan) {
				    			
				    			ImageView bi=getAbnormalTitanImage();
				    			LANE2.add(bi);
				    			lane2.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		else { 
				    			ImageView bi=getArmoredTitanImage();
				    			LANE2.add(bi);
				    			lane2.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		}
				    		
				    		if(battle.getOriginalLanes().indexOf(lane)==2) {
					    		if(titan instanceof PureTitan) {
					    			ImageView bi=getPureTitanImage();
					    			LANE3.add(bi);
					    			lane3.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else if(titan instanceof ColossalTitan) {
					    			ImageView bi=getCollosalTitanImage();
					    			LANE3.add(bi);
					    			lane3.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else if(titan instanceof AbnormalTitan) {
					    			ImageView bi=getAbnormalTitanImage();
					    			LANE3.add(bi);
					    			lane3.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else {
					    			ImageView bi=getArmoredTitanImage();
					    			LANE3.add(bi);
					    			lane3.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}}
				    		
				    		
				    				
				    		}
				  
						}	
						
				    	
			   }
				 /////////////////////////////////////////////////////////
				 public void updateHealthAndDangerLevel(){	
					 		health1E.setText(updateWall1Health() + "\n" +updatelane1Dl() );
		    				health2E.setText(updateWall2Health() + "\n" + updatelane2Dl());
		    				health3E.setText(updateWall2Health()+ "\n" +updatelane3Dl());
				 }
				 public void updateResources() {
					 int a = 750+battle.getResourcesGathered();
					 
					 String resAA=""+a;
					 resA.setText(resAA);
				 }
				 public void updateScore() {
					 int a = battle.getScore();
					 String resAA=""+a;
					 scoreA.setText(resAA);
				 }
				 public void updateRound() {
					 int a=battle.getNumberOfTurns();
					 String resAA=""+a;
					 roundnum.setText(resAA);
				 }
				 public void updateLane() {
					 if(battle.getOriginalLanes().get(0).isLaneLost()) {
						 displayAlert("lane lost", "lane 1's wall has been breached");
						 health1E.setText("lane lost");}
					 if(battle.getOriginalLanes().get(1).isLaneLost()) {
						 displayAlert("lane lost", "lane 2's wall has been breached");
						 health2E.setText("lane lost");}
					 if(battle.getOriginalLanes().get(2).isLaneLost()) {
						 displayAlert("lane lost", "lane 3's wall has been breached");
						 health3E.setText("lane lost");}}
				 public void updatePhase() {
					 String res=""+battle.getBattlePhase();
					 currentPhaseA.setText(res);
				 } 
				 public void updateTitans() {
					 titan1E.clear();
					 titan2E.clear();
					 titan3E.clear();
					 for(Titan t:battle.getOriginalLanes().get(0).getTitans()) {
						 String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
						  titan1E.appendText(res);
					 }
					 for(Titan t:battle.getOriginalLanes().get(1).getTitans()) {
						 String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
						  titan2E.appendText(res);
					 }
					 for(Titan t:battle.getOriginalLanes().get(2).getTitans()) {
						 String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
						  titan3E.appendText(res);
					 }
					 
				 }
				@Override
				public void handle(Event arg0) {
					try {
						/*if(battle.getOriginalLanes().get(currentLane).isLaneLost()) {
							throw new InvalidLaneException();
						}*/
						battle.purchaseWeapon(1, battle.getOriginalLanes().get(currentLane));
					}catch(InsufficientResourcesException e) {
						displayAlert("InssufficientResources","enta mfls");
					} catch (InvalidLaneException e) {
						displayAlert("InvalidLaneException","el lane day3 ");}
					if(currentLane==0) {
						l1.appendText(battle.getWeaponFactory().getWeaponShop().get(1).getName()+" \n"); 		
					    	}		    			
					else if(currentLane==1) {
						l2.appendText(battle.getWeaponFactory().getWeaponShop().get(1).getName()+"\n  ");}
					else if(currentLane==2) {
						l3.appendText(battle.getWeaponFactory().getWeaponShop().get(1).getName()+"\n  ");}
					
					updateHealthAndDangerLevel();					
					addTitans();
					updateTitans();
					updateResources();
					updateScore();
					updateRound();
					updateLane();
					gameOver();
					updatePhase();
					}}
				 	 
			 );
			   
			 addWeapon2.setOnMouseClicked(new EventHandler<Event>() {
				 public void gameOver() {
					  if(battle.getOriginalLanes().get(0).isLaneLost()&&battle.getOriginalLanes().get(1).isLaneLost()&&battle.getOriginalLanes().get(2).isLaneLost()) {
						  displayAlert("Game Over","all lanes are lost return to start menu");
					  primaryStage.close();
					  primaryStage.setScene(scene);
					  primaryStage.show();
					  primaryStage.setMaximized(true);}
				  }
				 public void addTitans() {
					    ArrayList<ImageView> LANE1=new ArrayList<ImageView>();
					    ArrayList<ImageView> LANE2=new ArrayList<ImageView>();
					    ArrayList<ImageView> LANE3=new ArrayList<ImageView>();
					   
						for(Lane lane:battle.getOriginalLanes()) {
				    	for(Titan titan:lane.getTitans()) {
				    		if(battle.getOriginalLanes().indexOf(lane)==0) {
				    		if(titan instanceof PureTitan)
				    			{
				    			ImageView bi=getPureTitanImage();
				    			LANE1.add(bi);
				    			lane1.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		else if(titan instanceof ColossalTitan) {
				    			ImageView bi=getCollosalTitanImage();
				    			LANE1.add(bi);
				    			lane1.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		else if(titan instanceof AbnormalTitan) {
				    			
				    			ImageView bi=getAbnormalTitanImage();
				    			LANE1.add(bi);
				    			lane1.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);}
				    		else { 
				    			ImageView bi=getArmoredTitanImage();
				    			LANE1.add(bi);
				    			lane1.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		}
				    		if(battle.getOriginalLanes().indexOf(lane)==1) {
				    			if(titan instanceof PureTitan)
				    			{
				    			ImageView bi=getPureTitanImage();
				    			LANE2.add(bi);
				    			lane2.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		else if(titan instanceof ColossalTitan) {
				    			ImageView bi=getCollosalTitanImage();
				    			LANE2.add(bi);
				    			lane2.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);			    			}
				    		else if(titan instanceof AbnormalTitan) {
				    			
				    			ImageView bi=getAbnormalTitanImage();
				    			LANE2.add(bi);
				    			lane2.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		else { 
				    			ImageView bi=getArmoredTitanImage();
				    			LANE2.add(bi);
				    			lane2.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		}
				    		
				    		if(battle.getOriginalLanes().indexOf(lane)==2) {
					    		if(titan instanceof PureTitan) {
					    			ImageView bi=getPureTitanImage();
					    			LANE3.add(bi);
					    			lane3.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else if(titan instanceof ColossalTitan) {
					    			ImageView bi=getCollosalTitanImage();
					    			LANE3.add(bi);
					    			lane3.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else if(titan instanceof AbnormalTitan) {
					    			ImageView bi=getAbnormalTitanImage();
					    			LANE3.add(bi);
					    			lane3.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else {
					    			ImageView bi=getArmoredTitanImage();
					    			LANE3.add(bi);
					    			lane3.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}}
				    		
				    		
				    				
				    		}
				  
						}	
						
				    	
			   }
				 //add void update resources and update score 
				 /////////////////////////////////////////////////////////
				 public void updateHealthAndDangerLevel(){	
				 		health1E.setText(updateWall1Health() + "\n" +updatelane1Dl() );
	    				health2E.setText(updateWall2Health() + "\n" + updatelane2Dl());
	    				health3E.setText(updateWall2Health()+ "\n" +updatelane3Dl());
				 }
				 public void updateResources() {
					 int a = 750+battle.getResourcesGathered();
					 String resAA=""+a;
					 resA.setText(resAA);
				 }
				 public void updateScore() {
					 int a = battle.getScore();
					 String resAA=""+a;
					 scoreA.setText(resAA);
				 }
				 public void updateRound() {
					 int a=battle.getNumberOfTurns();
					 String resAA=""+a;
					 roundnum.setText(resAA);
				 }
				 public void updateLane() {
					 if(battle.getOriginalLanes().get(0).isLaneLost()) {
						 displayAlert("lane lost", "lane 1's wall has been breached");
						 health1E.setText("lane lost");}
					 if(battle.getOriginalLanes().get(1).isLaneLost()) {
						 displayAlert("lane lost", "lane 2's wall has been breached");
						 health2E.setText("lane lost");}
					 if(battle.getOriginalLanes().get(2).isLaneLost()) {
						 displayAlert("lane lost", "lane 3's wall has been breached");
						 health3E.setText("lane lost");}}
				 public void updatePhase() {
					 String res=""+battle.getBattlePhase();
					 currentPhaseA.setText(res);
				 } 
				 public void updateTitans() {
					 titan1E.clear();
					 titan2E.clear();
					 titan3E.clear();
					 for(Titan t:battle.getOriginalLanes().get(0).getTitans()) {
						 String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
						  titan1E.appendText(res);
					 }
					 for(Titan t:battle.getOriginalLanes().get(1).getTitans()) {
						 String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
						  titan2E.appendText(res);
					 }
					 for(Titan t:battle.getOriginalLanes().get(2).getTitans()) {
						 String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
						  titan3E.appendText(res);
					 }
					 
				 }
					@Override
					public void handle(Event arg0) {
						try {
							if(battle.getOriginalLanes().get(currentLane).isLaneLost()) {
								throw new InvalidLaneException();
							}
							battle.purchaseWeapon(2, battle.getOriginalLanes().get(currentLane));
						}catch(InsufficientResourcesException e) {
							displayAlert("InssufficientResources","enta mfls");
						} catch (InvalidLaneException e) {
							displayAlert("InvalidLaneException","el lane day3 ");}
						if(currentLane==0)
							l1.appendText(battle.getWeaponFactory().getWeaponShop().get(2).getName()+" \n ");
						else if(currentLane==1)
							l2.appendText(battle.getWeaponFactory().getWeaponShop().get(2).getName()+"\n  ");
						else if(currentLane==2)
							l3.appendText(battle.getWeaponFactory().getWeaponShop().get(2).getName()+" \n ");
						
						updateHealthAndDangerLevel();
						
						addTitans();
						updateTitans();
						updateResources();
						updateScore();
						updateRound();
						updateLane();
						gameOver();
						updatePhase();
						}
					 
				 });
			 addWeapon3.setOnMouseClicked(new EventHandler<Event>() {
				 public void gameOver() {
					  if(battle.getOriginalLanes().get(0).isLaneLost()&&battle.getOriginalLanes().get(1).isLaneLost()&&battle.getOriginalLanes().get(2).isLaneLost()) {
						  displayAlert("Game Over","all lanes are lost return to start menu");
					  primaryStage.close();
					  primaryStage.setScene(scene);
					  primaryStage.show();
					  primaryStage.setMaximized(true);}
				  }
				 public void addTitans() {
					    ArrayList<ImageView> LANE1=new ArrayList<ImageView>();
					    ArrayList<ImageView> LANE2=new ArrayList<ImageView>();
					    ArrayList<ImageView> LANE3=new ArrayList<ImageView>();
					   
						for(Lane lane:battle.getOriginalLanes()) {
				    	for(Titan titan:lane.getTitans()) {
				    		if(battle.getOriginalLanes().indexOf(lane)==0) {
				    		if(titan instanceof PureTitan)
				    			{
				    			ImageView bi=getPureTitanImage();
				    			LANE1.add(bi);
				    			lane1.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		else if(titan instanceof ColossalTitan) {
				    			ImageView bi=getCollosalTitanImage();
				    			LANE1.add(bi);
				    			lane1.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		else if(titan instanceof AbnormalTitan) {
				    			
				    			ImageView bi=getAbnormalTitanImage();
				    			LANE1.add(bi);
				    			lane1.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);}
				    		else { 
				    			ImageView bi=getArmoredTitanImage();
				    			LANE1.add(bi);
				    			lane1.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		}
				    		if(battle.getOriginalLanes().indexOf(lane)==1) {
				    			if(titan instanceof PureTitan)
				    			{
				    			ImageView bi=getPureTitanImage();
				    			LANE2.add(bi);
				    			lane2.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		else if(titan instanceof ColossalTitan) {
				    			ImageView bi=getCollosalTitanImage();
				    			LANE2.add(bi);
				    			lane2.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);			    			}
				    		else if(titan instanceof AbnormalTitan) {
				    			
				    			ImageView bi=getAbnormalTitanImage();
				    			LANE2.add(bi);
				    			lane2.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		else { 
				    			ImageView bi=getArmoredTitanImage();
				    			LANE2.add(bi);
				    			lane2.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		}
				    		
				    		if(battle.getOriginalLanes().indexOf(lane)==2) {
					    		if(titan instanceof PureTitan) {
					    			ImageView bi=getPureTitanImage();
					    			LANE3.add(bi);
					    			lane3.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else if(titan instanceof ColossalTitan) {
					    			ImageView bi=getCollosalTitanImage();
					    			LANE3.add(bi);
					    			lane3.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else if(titan instanceof AbnormalTitan) {
					    			ImageView bi=getAbnormalTitanImage();
					    			LANE3.add(bi);
					    			lane3.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else {
					    			ImageView bi=getArmoredTitanImage();
					    			LANE3.add(bi);
					    			lane3.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}}
				    		
				    		
				    				
				    		}
				  
						}	
						
				    	
			   }
				 //add void update resources and update score 
				 /////////////////////////////////////////////////////////
				 public void updateHealthAndDangerLevel(){	
				 		health1E.setText(updateWall1Health() + "\n" +updatelane1Dl() );
	    				health2E.setText(updateWall2Health() + "\n" + updatelane2Dl());
	    				health3E.setText(updateWall2Health()+ "\n" +updatelane3Dl());
				 }
				 public void updateResources() {
					 int a =750+ battle.getResourcesGathered();
					 String resAA=""+a;
					 resA.setText(resAA);
				 }
				 public void updateScore() {
					 int a = battle.getScore();
					 String resAA=""+a;
					 scoreA.setText(resAA);
				 }
				 public void updateRound() {
					 int a=battle.getNumberOfTurns();
					 String resAA=""+a;
					 roundnum.setText(resAA);
				 }
				 public void updateLane() {
					 if(battle.getOriginalLanes().get(0).isLaneLost()) {
						 displayAlert("lane lost", "lane 1's wall has been breached");
						 health1E.setText("lane lost");}
					 if(battle.getOriginalLanes().get(1).isLaneLost()) {
						 displayAlert("lane lost", "lane 2's wall has been breached");
						 health2E.setText("lane lost");}
					 if(battle.getOriginalLanes().get(2).isLaneLost()) {
						 displayAlert("lane lost", "lane 3's wall has been breached");
						 health3E.setText("lane lost");}}
				 public void updatePhase() {
					 String res=""+battle.getBattlePhase();
					 currentPhaseA.setText(res);
				 } 
				 public void updateTitans() {
					 titan1E.clear();
					 titan2E.clear();
					 titan3E.clear();
					 for(Titan t:battle.getOriginalLanes().get(0).getTitans()) {
						 String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
						  titan1E.appendText(res);
					 }
					 for(Titan t:battle.getOriginalLanes().get(1).getTitans()) {
						 String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
						  titan2E.appendText(res);
					 }
					 for(Titan t:battle.getOriginalLanes().get(2).getTitans()) {
						 String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
						  titan3E.appendText(res);
					 }
					 
				 }
					@Override
					public void handle(Event arg0) {
						try {
							if(battle.getOriginalLanes().get(currentLane).isLaneLost()) {
								throw new InvalidLaneException();
							}
							battle.purchaseWeapon(3, battle.getOriginalLanes().get(currentLane));
						}catch(InsufficientResourcesException e) {
							displayAlert("InssufficientResources","enta mfls");
						} catch (InvalidLaneException e) {
							displayAlert("InvalidLaneException","el lane day3 ");}
						if(currentLane==0)
							l1.appendText(battle.getWeaponFactory().getWeaponShop().get(3).getName()+"\n  ");
						else if(currentLane==1)
							l2.appendText(battle.getWeaponFactory().getWeaponShop().get(3).getName()+"\n  ");
						else if(currentLane==2)
							l3.appendText(battle.getWeaponFactory().getWeaponShop().get(3).getName()+"\n  ");
					
			    		
						updateHealthAndDangerLevel();
						
						addTitans();
						updateTitans();
						updateResources();
						updateScore();
						updateRound();
						updateLane();
						gameOver();
						updatePhase();
					
					
					
					}
					
					 
				 });
			 addWeapon4.setOnMouseClicked(new EventHandler<Event>() {
				 public void gameOver() {
					  if(battle.getOriginalLanes().get(0).isLaneLost()&&battle.getOriginalLanes().get(1).isLaneLost()&&battle.getOriginalLanes().get(2).isLaneLost()) {
						  displayAlert("Game Over","all lanes are lost return to start menu");
					  primaryStage.close();
					  primaryStage.setScene(scene);
					  primaryStage.show();
					  primaryStage.setMaximized(true);}
				  }
				  
				 public void addTitans() {
					    ArrayList<ImageView> LANE1=new ArrayList<ImageView>();
					    ArrayList<ImageView> LANE2=new ArrayList<ImageView>();
					    ArrayList<ImageView> LANE3=new ArrayList<ImageView>();
					   
						for(Lane lane:battle.getOriginalLanes()) {
				    	for(Titan titan:lane.getTitans()) {
				    		if(battle.getOriginalLanes().indexOf(lane)==0) {
				    		if(titan instanceof PureTitan)
				    			{
				    			ImageView bi=getPureTitanImage();
				    			LANE1.add(bi);
				    			lane1.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		else if(titan instanceof ColossalTitan) {
				    			ImageView bi=getCollosalTitanImage();
				    			LANE1.add(bi);
				    			lane1.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		else if(titan instanceof AbnormalTitan) {
				    			
				    			ImageView bi=getAbnormalTitanImage();
				    			LANE1.add(bi);
				    			lane1.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);}
				    		else { 
				    			ImageView bi=getArmoredTitanImage();
				    			LANE1.add(bi);
				    			lane1.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		}
				    		if(battle.getOriginalLanes().indexOf(lane)==1) {
				    			if(titan instanceof PureTitan)
				    			{
				    			ImageView bi=getPureTitanImage();
				    			LANE2.add(bi);
				    			lane2.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		else if(titan instanceof ColossalTitan) {
				    			ImageView bi=getCollosalTitanImage();
				    			LANE2.add(bi);
				    			lane2.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);			    			}
				    		else if(titan instanceof AbnormalTitan) {
				    			
				    			ImageView bi=getAbnormalTitanImage();
				    			LANE2.add(bi);
				    			lane2.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		else { 
				    			ImageView bi=getArmoredTitanImage();
				    			LANE2.add(bi);
				    			lane2.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		}
				    		
				    		if(battle.getOriginalLanes().indexOf(lane)==2) {
					    		if(titan instanceof PureTitan) {
					    			ImageView bi=getPureTitanImage();
					    			LANE3.add(bi);
					    			lane3.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else if(titan instanceof ColossalTitan) {
					    			ImageView bi=getCollosalTitanImage();
					    			LANE3.add(bi);
					    			lane3.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else if(titan instanceof AbnormalTitan) {
					    			ImageView bi=getAbnormalTitanImage();
					    			LANE3.add(bi);
					    			lane3.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else {
					    			ImageView bi=getArmoredTitanImage();
					    			LANE3.add(bi);
					    			lane3.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}}
				    		
				    		
				    				
				    		}
				  
						}	
						
				    	
			   }
				 //add void update resources and update score 
				 /////////////////////////////////////////////////////////
				 public void updateHealthAndDangerLevel(){	
				 		health1E.setText(updateWall1Health() + "\n" +updatelane1Dl() );
	    				health2E.setText(updateWall2Health() + "\n" + updatelane2Dl());
	    				health3E.setText(updateWall2Health()+ "\n" +updatelane3Dl());
				 }
				 public void updateResources() {
					 int a = battle.getResourcesGathered();
					 String resAA=""+a;
					 resA.setText(resAA);
				 }
				 public void updateScore() {
					 int a = battle.getScore();
					 String resAA=""+a;
					 scoreA.setText(resAA);
				 }
				 public void updateRound() {
					 int a=battle.getNumberOfTurns();
					 String resAA=""+a;
					 roundnum.setText(resAA);
				 }
		         
				 public void updateLane() {
					 if(battle.getOriginalLanes().get(0).isLaneLost()) {
						 displayAlert("lane lost", "lane 1's wall has been breached");
						 health1E.setText("lane lost");}
					 if(battle.getOriginalLanes().get(1).isLaneLost()) {
						 displayAlert("lane lost", "lane 2's wall has been breached");
						 health2E.setText("lane lost");}
					 if(battle.getOriginalLanes().get(2).isLaneLost()) {
						 displayAlert("lane lost", "lane 3's wall has been breached");
						 health3E.setText("lane lost");}}
				 public void updatePhase() {
					 String res=""+battle.getBattlePhase();
					 currentPhaseA.setText(res);
				 } 
				 public void updateTitans() {
					 titan1E.clear();
					 titan2E.clear();
					 titan3E.clear();
					 for(Titan t:battle.getOriginalLanes().get(0).getTitans()) {
						 String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
						  titan1E.appendText(res);
					 }
					 for(Titan t:battle.getOriginalLanes().get(1).getTitans()) {
						 String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
						  titan2E.appendText(res);
					 }
					 for(Titan t:battle.getOriginalLanes().get(2).getTitans()) {
						 String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
						  titan3E.appendText(res);
					 }
					 
				 }
					@Override
					public void handle(Event arg0) {
						try {
							if(battle.getOriginalLanes().get(currentLane).isLaneLost()) {
								throw new InvalidLaneException();
							}
							battle.purchaseWeapon(4, battle.getOriginalLanes().get(currentLane));
						}catch(InsufficientResourcesException e) {
							displayAlert("InssufficientResources","enta mfls");
						} catch (InvalidLaneException e) {
							displayAlert("InvalidLaneException","el lane day3 ");}
						if(currentLane==0)
							l1.appendText(battle.getWeaponFactory().getWeaponShop().get(4).getName()+" \n ");
						else if(currentLane==1)
							l2.appendText(battle.getWeaponFactory().getWeaponShop().get(4).getName()+"\n  ");
						else if(currentLane==2)
							l3.appendText(battle.getWeaponFactory().getWeaponShop().get(4).getName()+" \n ");
			    		
						updateHealthAndDangerLevel();
						addTitans();
						updateTitans();
						updateResources();
						updateScore();
						updateRound();
					    updateLane();
					    gameOver();
					    updatePhase();
					
					}
					 
				 });
		      
		       addWeapon1.isDisable();
		       addWeapon2.isDisable();
		       addWeapon3.isDisable();
		       addWeapon4.isDisable();
		       firstLane.setOnMouseClicked(new EventHandler<Event>() {
		    	    @Override
		    	    public void handle(Event event) {
		    	        currentLane = 0;
		    	        // Enable the corresponding "Add weapon" buttons
		    	        addWeapon1.setDisable(false);
		    	        addWeapon2.setDisable(false);
		    	        addWeapon3.setDisable(false);
		    	        addWeapon4.setDisable(false);
		    	    }
		    	});
		       secondLane.setOnMouseClicked(new EventHandler<Event>() {
		    	    @Override
		    	    public void handle(Event event) {
		    	        currentLane = 1;
		    	        // Enable the corresponding "Add weapon" buttons
		    	        addWeapon1.setDisable(false);
		    	        addWeapon2.setDisable(false);
		    	        addWeapon3.setDisable(false);
		    	        addWeapon4.setDisable(false);
		    	    }
		    	});
		       thirdLane.setOnMouseClicked(new EventHandler<Event>() {
		    	    @Override
		    	    public void handle(Event event) {
		    	        currentLane = 2;
		    	        // Enable the corresponding "Add weapon" buttons
		    	        addWeapon1.setDisable(false);
		    	        addWeapon2.setDisable(false);
		    	        addWeapon3.setDisable(false);
		    	        addWeapon4.setDisable(false);
		    	    }
		    	});
			
		}
		 
	 });

	 ////////////////////////////////////////////////////hard edit

	 //
	 
	 
	 
	 
	 
	 
	
	 hard2.setOnMouseClicked(new EventHandler<Event>() {
		 
			@Override
			public void handle(Event event) {
				try {
					gameDiff();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				BorderPane mainHard = new BorderPane();
				 String gameImage33="file:///Users//ahmed//Downloads//mainGame.png";
				   Image gameImage3=new Image(gameImage33);
				   ImageView gameview=new ImageView(gameImage3);
				   BackgroundSize backgroundSizes = new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, true);
				   BackgroundImage background3 = new BackgroundImage(
				            gameImage3,
				            BackgroundRepeat.NO_REPEAT,
				            BackgroundRepeat.NO_REPEAT,
				            BackgroundPosition.DEFAULT,
				            backgroundSizes
				    );
				   Background backgroundStyle3 = new Background(background3);
				   
				// Create a VBox to hold all the lanes
				VBox lanez= new VBox();
				lanez.setSpacing(20);
				lanez.setMaxWidth(600);
				// Adjust spacing between lanes
				Pane lanePane1 = new Pane();
				lanePane1.setMaxWidth(600);
				lanePane1.setMaxHeight(200);
				Pane lanePane2 = new Pane();
				lanePane2.setMaxWidth(600);
				lanePane2.setMaxHeight(200);
				Pane lanePane3 = new Pane();
				lanePane3.setMaxWidth(600);
				lanePane3.setMaxHeight(200);
				Pane lanePane4 = new Pane();
				lanePane4.setMaxWidth(600);
				lanePane4.setMaxHeight(200);
				Pane lanePane5 = new Pane();
				lanePane5.setMaxWidth(600);
				lanePane5.setMaxHeight(200);
				lanez.getChildren().addAll(lanePane1,lanePane2,lanePane3,lanePane4,lanePane5);
				// Create a VBox to hold all the walls
				VBox wallS = new VBox();
				// Adjust spacing between walls
				Pane wallPane1 = new Pane();
				Pane wallPane2 = new Pane();
				Pane wallPane3 = new Pane();
				Pane wallPane4 = new Pane();
				Pane wallPane5= new Pane();
				ImageView wallView1= new ImageView(new Image("file:///Users//ahmed//Downloads//wall.jpeg"));
				wallView1.setFitWidth(200); // Set the desired width
				wallView1.setFitHeight(200);
				ImageView wallView2 = new ImageView(new Image("file:///Users//ahmed//Downloads//wall.jpeg"));
				wallView2.setFitWidth(200); // Set the desired width
				wallView2.setFitHeight(200);
				ImageView wallView3 = new ImageView(new Image("file:///Users//ahmed//Downloads//wall.jpeg"));
				wallView3.setFitWidth(200); // Set the desired width
				wallView3.setFitHeight(200);
				ImageView wallView4 = new ImageView(new Image("file:///Users//ahmed//Downloads//wall.jpeg"));
				wallView4.setFitWidth(200); // Set the desired width
				wallView4.setFitHeight(200);
				ImageView wallView5 = new ImageView(new Image("file:///Users//ahmed//Downloads//wall.jpeg"));
				wallView5.setFitWidth(200); // Set the desired width
				wallView5.setFitHeight(200);
				wallPane1.getChildren().add(wallView1);
				wallPane2.getChildren().add(wallView2);
				wallPane3.getChildren().add(wallView3);
				wallPane4.getChildren().add(wallView4);
				wallPane5.getChildren().add(wallView5);
				VBox weaponS = new VBox();
				weaponS.setSpacing(20); 
				Pane weaponPane1 = new Pane();
				Pane weaponPane2 = new Pane();
				Pane weaponPane3 = new Pane();
				Pane weaponPane4 = new Pane();
				Pane weaponPane5 = new Pane();
				TextArea health1=new TextArea("Health dl");
				health1.setMaxWidth(70);
				
				TextArea health2=new TextArea("Health dl");
				health2.setMaxWidth(70);
				TextArea health3=new TextArea("Health dl");
				health3.setMaxWidth(70);
				TextArea health4=new TextArea("Health dl");
				health4.setMaxWidth(70);
				TextArea health5=new TextArea("Health dl");
				health5.setMaxWidth(70);
				HBox healthDl1=new HBox();
				HBox healthDl2=new HBox();
				HBox healthDl3=new HBox();
				HBox healthDl4=new HBox();
				HBox healthDl5=new HBox();
				VBox titanDetails=new VBox();
				TextArea titan1=new TextArea("");
				TextArea titan2=new TextArea("");
				TextArea titan3=new TextArea("");
				TextArea titan4=new TextArea("");
				TextArea titan5=new TextArea("");
				titanDetails.getChildren().addAll(titan1,titan2,titan3,titan4,titan5);
				titanDetails.setMaxWidth(100);
				titan1.setMaxWidth(50);
				titan2.setMaxWidth(50);
				titan3.setMaxWidth(50);
				titan4.setMaxWidth(50);
				titan5.setMaxWidth(50);
				titan1.setEditable(false);
				titan2.setEditable(false);
				titan3.setEditable(false);
				titan4.setEditable(false);
				titan5.setEditable(false);
				healthDl1.getChildren().addAll(health1,wallPane1);
				
				healthDl2.getChildren().addAll(health2,wallPane2);
				
				healthDl3.getChildren().addAll(health3,wallPane3);
				
				healthDl4.getChildren().addAll(health4,wallPane4);
				
				healthDl5.getChildren().addAll(health5,wallPane5);
				
				TextArea weaponPaneTxt1=new TextArea("");
				weaponPaneTxt1.setMaxWidth(40);
				TextArea weaponPaneTxt2=new TextArea("");
				weaponPaneTxt2.setMaxWidth(40);
				TextArea weaponPaneTxt3=new TextArea("");
				weaponPaneTxt3.setMaxWidth(40);
				TextArea weaponPaneTxt4=new TextArea("");
				weaponPaneTxt4.setMaxWidth(40);
				TextArea weaponPaneTxt5=new TextArea("");
				weaponPaneTxt5.setMaxWidth(40);
				weaponPaneTxt1.setEditable(false);
				weaponPaneTxt2.setEditable(false);
				weaponPaneTxt3.setEditable(false);
				weaponPaneTxt4.setEditable(false);
				weaponPaneTxt5.setEditable(false);
				weaponPane1.getChildren().add(weaponPaneTxt1);
				weaponPane2.getChildren().add(weaponPaneTxt2);
				weaponPane3.getChildren().add(weaponPaneTxt3);
				weaponPane4.getChildren().add(weaponPaneTxt4);
				weaponPane5.getChildren().add(weaponPaneTxt5);
				weaponS.getChildren().addAll(weaponPane1,weaponPane2,weaponPane3,weaponPane4,weaponPane5);
				wallS.setMaxWidth(270);
				wallS.getChildren().addAll(healthDl1,healthDl2,healthDl3,healthDl4,healthDl5);
				lanez.setSpacing(20);
				wallS.setSpacing(20);
				lanez.setAlignment(Pos.CENTER);
				
				// Set alignment of lanes, walls, and weapons to center
				HBox centerBox = new HBox();
				centerBox.setAlignment(Pos.CENTER_LEFT); // Align elements to the center
				centerBox.setSpacing(20); // Adjust spacing between elements
                
				// Add the lanes, walls, and weapons to the center HBox
				
				centerBox.getChildren().addAll(weaponS,titanDetails, wallS, lanez);
				mainHard.setCenter(centerBox);
				Label roundHard = new Label("Round:");
				roundHard.setStyle(buttonHoveredStyleOrg);
				Label roundnumHard = new Label("1");
				roundnumHard.setStyle(buttonHoveredStyleOrg);
				Label ScoreH=new Label("Score:");
				ScoreH.setStyle(buttonHoveredStyleOrg);
				Label ScoreHA=new Label("0");
				ScoreHA.setStyle(buttonHoveredStyleOrg);
				HBox roundsHard = new HBox();
				roundsHard.getChildren().addAll(roundHard, roundnumHard,ScoreH,ScoreHA);
				roundsHard.setAlignment(Pos.CENTER);
				mainHard.setTop(roundsHard);
		        mainHard.setBackground(backgroundStyle3);
				// Create a BorderPane to hold the sub information
				BorderPane subHard = new BorderPane();

				// Create a VBox to hold the subtext information
				VBox subtextHard = new VBox();

				// Create labels for available resources
				Label resHard = new Label("Available resources");
				resHard.setStyle(buttonHoveredStyle2);
				
				Label resAHard = new Label("620");
                resAHard.setStyle(buttonHoveredStyle2);
				// Create an HBox to hold the current resources labels
				HBox currentresHard = new HBox();
				currentresHard.getChildren().addAll(resHard, resAHard);

				// Add the current resources HBox to the subtext VBox
				subtextHard.getChildren().add(currentresHard);

				// Create an HBox to hold the current phase information
				HBox phaseHard = new HBox();
				Label currentPhaseHard = new Label("Phase:");
				currentPhaseHard.setStyle(buttonHoveredStyle2);
				Label currentPhaseAHard = new Label("Early");
				currentPhaseAHard.setStyle(buttonHoveredStyle2);
				phaseHard.getChildren().addAll(currentPhaseHard, currentPhaseAHard);

				// Add the current phase HBox to the subtext VBox
				subtextHard.getChildren().add(phaseHard);

				// Set the center of the subHard BorderPane to the subtext VBox
				subHard.setCenter(subtextHard);

				// Create an HBox to hold the buttons
				HBox buttonsMHard = new HBox();
				Button purchaseHard = new Button("Purchase Weapon");
				Button passHard = new Button("Pass Turn");
                Button AIHard =new Button("best action for player");
				// Add the buttons to the buttons HBox
				buttonsMHard.getChildren().addAll(purchaseHard, passHard,AIHard);

				// Set the bottom of the subHard BorderPane to the buttons HBox
				subHard.setBottom(buttonsMHard);

				// Set the bottom of the mainHard BorderPane to the subHard BorderPane
				mainHard.setBottom(subHard);
				BorderPane.setAlignment(subHard, Pos.BOTTOM_RIGHT);
				

				// Create a Scene with the mainHard BorderPane and set the size
				Scene mainHardView = new Scene(mainHard, 1000, 600);
				primaryStage.setScene(mainHardView);
				primaryStage.show();
				 primaryStage.setMaximized(true);
				
				
				String left1=("Name: "+battle.getWeaponFactory().getWeaponShop().get(1).getName()+
						 "\nPrice: "+battle.getWeaponFactory().getWeaponShop().get(1).getPrice()+
						 "\nDamage: "+battle.getWeaponFactory().getWeaponShop().get(1).getDamage()+
						 "\nType: PiercingCannon");
				 String left2=("Name: "+battle.getWeaponFactory().getWeaponShop().get(2).getName()+
						 "\nPrice: "+battle.getWeaponFactory().getWeaponShop().get(2).getPrice()+
						 "\nDamage: "+battle.getWeaponFactory().getWeaponShop().get(2).getDamage()+
						 "\nType: SniperCannon");
				 String right1=("Name: "+battle.getWeaponFactory().getWeaponShop().get(3).getName()+
						 "\nPrice: "+battle.getWeaponFactory().getWeaponShop().get(3).getPrice()+
						 "\nDamage: "+battle.getWeaponFactory().getWeaponShop().get(3).getDamage()+
						 "\nType: VolleySpread");
				 String right2=("Name: "+battle.getWeaponFactory().getWeaponShop().get(4).getName()+
						 "\nPrice: "+battle.getWeaponFactory().getWeaponShop().get(4).getPrice()+
						 "\nDamage: "+battle.getWeaponFactory().getWeaponShop().get(4).getDamage()+
						 "\nType: WallTrap");
				 Label leftWeaponName1 = new Label(left1);
				 Label leftWeaponName2 = new Label(left2);
				 
				 ImageView imageView1 = new ImageView("file:///Users//ahmed//Downloads//wall.jpeg");
				 ImageView imageView2 = new ImageView("file:///Users//ahmed//Downloads//walltrap.jpeg");
				 imageView1.setFitWidth(300); // Adjust width as needed
			   imageView1.setFitHeight(300); // Adjust height as needed
			   imageView2.setFitWidth(300); // Adjust width as needed
			   imageView2.setFitHeight(300); // Adjust height as needed
			    ToggleGroup toggleGroupDiff = new ToggleGroup();
			   	//first lane button
			   	RadioButton firstLaneDiff = new  RadioButton("Lane 1");
			   	firstLaneDiff.setToggleGroup(toggleGroupDiff);
			   	
			   	//second lane button
			   	RadioButton secondLaneDiff = new RadioButton("Lane 2");
			   
			   	secondLaneDiff.setToggleGroup(toggleGroupDiff);
			   	
			   	//third lane button
			   	RadioButton thirdLaneDiff = new RadioButton("Lane 3");
			   	
			   	RadioButton fourthLaneDiff = new RadioButton("Lane 4");
			   
			   	RadioButton fifthLaneDiff = new RadioButton("Lane 5");
			   
			   	thirdLaneDiff.setToggleGroup(toggleGroupDiff);
			   	fourthLaneDiff.setToggleGroup(toggleGroupDiff);
			   	fifthLaneDiff.setToggleGroup(toggleGroupDiff);
			   	
			   	//hbox to insert the buttons
			   	HBox radioBDiff = new HBox();
			   	//adding the buttons to the hbox
			   	radioBDiff.getChildren().addAll(firstLaneDiff , secondLaneDiff , thirdLaneDiff , fourthLaneDiff , fifthLaneDiff);
			   	radioBDiff.setAlignment(Pos.TOP_CENTER);
			   	
			   	//making a border pane to add the hbox to it
			   	BorderPane rootHard = new BorderPane();
			   	//putting the buttons hbox in top centre
			   	BorderPane.setAlignment(radioBDiff, Pos.TOP_CENTER);
			   	
			   	 rootHard.setTop(radioBDiff);//putting the radioButtons in the root to create scene
			   	 //VBox weapons = new VBox();
			   	 /////////////////
			   	 TextArea leftWeaponName1Diff = new TextArea(left1);
				 TextArea leftWeaponName2Diff = new TextArea(left2);
				 
				 ImageView imageView1Diff = new ImageView("file:///Users//ahmed//Downloads/piercing cannon.jpeg");
				 ImageView imageView2Diff = new ImageView("file:///Users//ahmed//Downloads//sniper.jpeg");
				 imageView1Diff.setFitWidth(300); // Adjust width as needed
			   imageView1Diff.setFitHeight(300); // Adjust height as needed
			   imageView2Diff.setFitWidth(300); // Adjust width as needed
			   imageView2Diff.setFitHeight(300); // Adjust height as needed
			   
			   
				 //the button to buy the weapon
				 Button addWeapon1Diff = new Button("Add weapon 1");
				 Button addWeapon2Diff = new Button("Add weapon 2");
				 
				 //create a vbox to insert the image , the name and button
				 VBox wweaponsDiff = new VBox();
				  wweaponsDiff.setSpacing(10);
				 //putting all elements in the vbox
				 wweaponsDiff.getChildren().addAll(imageView1Diff, leftWeaponName1Diff, addWeapon1Diff ,imageView2Diff, leftWeaponName2Diff, addWeapon2Diff);
				 //aligning the elements to the left centre
				 BorderPane.setAlignment(wweaponsDiff, Pos.CENTER_LEFT);
				 BorderPane.setMargin(wweaponsDiff, new Insets(50, 0, 0, 180));
				 rootHard.setCenter(wweaponsDiff);
				 
				 
				 
				 
				 TextArea rightWeaponName3Diff = new TextArea(right1);
				 TextArea rightWeaponName4Diff = new TextArea(right2);
				 //image path
				 ImageView imageView3Diff = new ImageView("file:///Users//ahmed//Downloads//volleyspread.jpeg");/////////////////////
				 ImageView imageView4Diff = new ImageView("file:///Users//ahmed//Downloads//walltrap.jpeg");/////////////////////
				 imageView3Diff.setFitWidth(300); // Adjust width as needed
			   imageView3Diff.setFitHeight(300); // Adjust height as needed
			   imageView4Diff.setFitWidth(300); // Adjust width as needed
			   imageView4Diff.setFitHeight(300); // Adjust height as needed
			   
			   
				 //the button to buy the weapon
				 Button addWeapon3Diff = new Button("Add weapon 3");
				 Button addWeapon4Diff = new Button("Add weapon 4");
				 
				 
				 //create a vbox to insert the image , the name and button
				 VBox weaponsRightDiff = new VBox();
				  weaponsRightDiff.setSpacing(10);
				 //putting all elements in the vbox
				 weaponsRightDiff.getChildren().addAll(imageView3Diff, rightWeaponName3Diff, addWeapon3Diff ,imageView4Diff, rightWeaponName4Diff, addWeapon4Diff);
				 //aligning the elements to the left centre
				 BorderPane.setAlignment(weaponsRightDiff, Pos.CENTER_RIGHT);
				 BorderPane.setMargin(weaponsRightDiff, new Insets(50, 180, 0, 0));
				 rootHard.setRight(weaponsRightDiff);
				 Button returnGameDiff=new Button("Return");
				 returnGameDiff.setStyle(buttonHoveredStyleOrg);
				 rootHard.setBottom(returnGameDiff);
				 AIHard.setStyle(buttonHoveredStyle2);
				 BorderPane.setAlignment(returnGameDiff, Pos.BOTTOM_LEFT);

				 Scene shopsceneHard = new Scene(rootHard, 1000, 600);
				 firstLaneDiff.setOnMouseClicked(new EventHandler<Event>() {

						@Override
						public void handle(Event arg0) {
							currentLane=0;
							
						}
				   		
				   	});
					secondLaneDiff.setOnMouseClicked(new EventHandler<Event>() {

						@Override
						public void handle(Event arg0) {
							currentLane=1;
							
						}
				   		
				   	});
					thirdLaneDiff.setOnMouseClicked(new EventHandler<Event>() {

						@Override
						public void handle(Event arg0) {
							currentLane=2;
							
						}
				   		
				   	});
					fourthLaneDiff.setOnMouseClicked(new EventHandler<Event>() {

						@Override
						public void handle(Event arg0) {
							currentLane=3;
							
						}
				   		
				   	});
					fifthLaneDiff.setOnMouseClicked(new EventHandler<Event>() {

						@Override
						public void handle(Event arg0) {
							currentLane=4;
							
						}
				   		
				   	});
			   	  purchaseHard.setOnMouseClicked(new EventHandler<Event>() {

					@Override
					public void handle(Event arg0) {
						primaryStage.setScene(shopsceneHard);
						primaryStage.show();
						primaryStage.setMaximized(true);
						
					}
			   		  
			   	  });
			   	  AIHard.setOnMouseClicked(new EventHandler<Event>() {
			   		 public void gameOver() {
						  if(battle.getOriginalLanes().get(0).isLaneLost()&&battle.getOriginalLanes().get(1).isLaneLost()&&battle.getOriginalLanes().get(2).isLaneLost()&&battle.getOriginalLanes().get(3).isLaneLost()&&battle.getOriginalLanes().get(4).isLaneLost()) {
							  displayAlert("Game Over","all lanes are lost return to start menu");
						  primaryStage.close();
						  primaryStage.setScene(scene);
						  primaryStage.show();
						  primaryStage.setMaximized(true);}
					  }
				   	 public void addTitans() {
						    ArrayList<ImageView> LANE1=new ArrayList<ImageView>();
						    ArrayList<ImageView> LANE2=new ArrayList<ImageView>();
						    ArrayList<ImageView> LANE3=new ArrayList<ImageView>();
						   
							for(Lane lane:battle.getOriginalLanes()) {
					    	for(Titan titan:lane.getTitans()) {
					    		if(battle.getOriginalLanes().indexOf(lane)==0) {
					    		if(titan instanceof PureTitan)
					    			{
					    			ImageView bi=getPureTitanImage();
					    			LANE1.add(bi);
					    			lanePane1.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);
					    			}
					    		else if(titan instanceof ColossalTitan) {
					    			ImageView bi=getCollosalTitanImage();
					    			LANE1.add(bi);
					    			lanePane1.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);
					    			}
					    		else if(titan instanceof AbnormalTitan) {
					    			
					    			ImageView bi=getAbnormalTitanImage();
					    			LANE1.add(bi);
					    			lanePane1.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else { 
					    			ImageView bi=getArmoredTitanImage();
					    			LANE1.add(bi);
					    			lanePane1.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);
					    			}
					    		}
					    		if(battle.getOriginalLanes().indexOf(lane)==1) {
					    			if(titan instanceof PureTitan)
					    			{
					    			ImageView bi=getPureTitanImage();
					    			LANE2.add(bi);
					    			lanePane2.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);
					    			}
					    		else if(titan instanceof ColossalTitan) {
					    			ImageView bi=getCollosalTitanImage();
					    			LANE2.add(bi);
					    			lanePane2.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);			    			}
					    		else if(titan instanceof AbnormalTitan) {
					    			
					    			ImageView bi=getAbnormalTitanImage();
					    			LANE2.add(bi);
					    			lanePane2.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);
					    			}
					    		else { 
					    			ImageView bi=getArmoredTitanImage();
					    			LANE2.add(bi);
					    			lanePane2.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);
					    			}
					    		}
					    		
					    		if(battle.getOriginalLanes().indexOf(lane)==2) {
						    		if(titan instanceof PureTitan) {
						    			ImageView bi=getPureTitanImage();
						    			LANE3.add(bi);
						    			lanePane3.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else if(titan instanceof ColossalTitan) {
						    			ImageView bi=getCollosalTitanImage();
						    			LANE3.add(bi);
						    			lanePane3.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else if(titan instanceof AbnormalTitan) {
						    			ImageView bi=getAbnormalTitanImage();
						    			LANE3.add(bi);
						    			lanePane3.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else {
						    			ImageView bi=getArmoredTitanImage();
						    			LANE3.add(bi);
						    			lanePane3.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}}
					    		if(battle.getOriginalLanes().indexOf(lane)==3) {
					    			if(titan instanceof PureTitan) {
						    			ImageView bi=getPureTitanImage();
						    			LANE3.add(bi);
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else if(titan instanceof ColossalTitan) {
						    			ImageView bi=getCollosalTitanImage();
						    			LANE3.add(bi);
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else if(titan instanceof AbnormalTitan) {
						    			ImageView bi=getAbnormalTitanImage();
						    			LANE3.add(bi);
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else {
						    			ImageView bi=getArmoredTitanImage();
						    			LANE3.add(bi);
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
					    		}
					    		
					    		if(battle.getOriginalLanes().indexOf(lane)==4) {
						    		if(titan instanceof PureTitan) {
						    			ImageView bi=getPureTitanImage();
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else if(titan instanceof ColossalTitan) {
						    			ImageView bi=getCollosalTitanImage();
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);
						    			}
						    		else if(titan instanceof AbnormalTitan) {
						    			ImageView bi=getAbnormalTitanImage();
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else {ImageView bi=getArmoredTitanImage();
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		}
					    		
							
					    	
				   
						    		
						   
						    		
					    	}}
					   }
						 //add void update resources and update score 
						 /////////////////////////////////////////////////////////
				   		 public String updateWall5Health() {
							   int temp=battle.getOriginalLanes().get(4).getLaneWall().getCurrentHealth();
							   String ret=""+ temp;
							   return "Health= "+ret;}
						 public void updateHealthAndDangerLevel(){	
						 		health1.setText(updateWall1Health() + "\n" +updatelane1Dl() );
			    				health2.setText(updateWall2Health() + "\n" + updatelane2Dl());
			    				health3.setText(updateWall3Health()+ "\n" +updatelane3Dl());
			    				health4.setText(updateWall4Health()+ "\n" +updatelane4Dl());
			    				health5.setText(updateWall5Health()+ "\n" +updatelane5Dl());
					 }		
						
						 public void updateScore() {
							 int a = battle.getScore();
							 String resAA=""+a;
							 ScoreHA.setText(resAA);
						 }
						 public void updateRound() {
							 int a=battle.getNumberOfTurns();
							 String resAA=""+a;
							 roundnumHard.setText(resAA);
						 }
				         
						 public void updateLane() {
							 if(battle.getOriginalLanes().get(0).isLaneLost()) {
								 displayAlert("lane lost", "lane 1's wall has been breached");
								 health1.setText("lane lost");}
							 if(battle.getOriginalLanes().get(1).isLaneLost()) {
								 displayAlert("lane lost", "lane 2's wall has been breached");
								 health2.setText("lane lost");}
							 if(battle.getOriginalLanes().get(2).isLaneLost()) {
								 displayAlert("lane lost", "lane 3's wall has been breached");
								 health3.setText("lane lost");}
							 if(battle.getOriginalLanes().get(3).isLaneLost()) {
								 displayAlert("lane lost", "lane 4's wall has been breached");
								 health4.setText("lane lost");}
							 if(battle.getOriginalLanes().get(4).isLaneLost()) {
								 displayAlert("lane lost", "lane 5's wall has been breached");
								 health5.setText("lane lost");}
							 
						 }
						 public void updatePhase() {
							 String res=""+battle.getBattlePhase();
							 currentPhaseAHard.setText(res);
						 } 
						  public void updateTitans() {
							  titan1.clear();
							  titan2.clear();
							  titan3.clear();
							  titan4.clear();
							  titan5.clear();
							  for(Titan t:battle.getOriginalLanes().get(0).getTitans()) {
								  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
								  titan1.appendText(res);
							  }
							  for(Titan t :battle.getOriginalLanes().get(1).getTitans()) {
								  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
								  titan2.appendText(res);
							  }
							  for(Titan t:battle.getOriginalLanes().get(2).getTitans()) {
								  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
								  titan3.appendText(res);
							  }
							  for(Titan t:battle.getOriginalLanes().get(3).getTitans()) {
								  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
								  titan4.appendText(res);
							  }
							  for(Titan t:battle.getOriginalLanes().get(4).getTitans()) {
								  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
								  titan5.appendText(res);
							  }
						  }
						  public int random() {
							  int res=(int)(Math.random()*5+1);
							  return res;
						  }
						@Override
						public void handle(Event arg0) {
							try {
								if(battle.getOriginalLanes().get(currentLane).isLaneLost()) {
									throw new InvalidLaneException();
								}
								if(battle.getResourcesGathered()>=100) {
									int r=random();
								battle.purchaseWeapon(3, battle.getOriginalLanes().get(r));
								switch(r) {
								case 1: weaponPaneTxt1.appendText(battle.getWeaponFactory().getWeaponShop().get(3).getName()+" \n ");break;
								case 2: weaponPaneTxt2.appendText(battle.getWeaponFactory().getWeaponShop().get(3).getName()+"\n  ");break;
								case 3: weaponPaneTxt3.appendText(battle.getWeaponFactory().getWeaponShop().get(3).getName()+"\n  ");break;
								case 4: weaponPaneTxt4.appendText(battle.getWeaponFactory().getWeaponShop().get(3).getName()+" \n ");break;
								default: weaponPaneTxt5.appendText(battle.getWeaponFactory().getWeaponShop().get(3).getName()+"\n  ");break;}
								}
								else if(battle.getResourcesGathered()<100 && battle.getResourcesGathered()>=75) {
									int r=random();
									battle.purchaseWeapon(4, battle.getOriginalLanes().get(r));
									switch(r) {
									case 1: weaponPaneTxt1.appendText(battle.getWeaponFactory().getWeaponShop().get(4).getName()+" \n ");break;
									case 2: weaponPaneTxt2.appendText(battle.getWeaponFactory().getWeaponShop().get(4).getName()+"\n  ");break;
									case 3: weaponPaneTxt3.appendText(battle.getWeaponFactory().getWeaponShop().get(4).getName()+" \n ");break;
									case 4: weaponPaneTxt4.appendText(battle.getWeaponFactory().getWeaponShop().get(4).getName()+" \n ");break;
									default: weaponPaneTxt5.appendText(battle.getWeaponFactory().getWeaponShop().get(4).getName()+"\n  ");break;
									}
								}
								else if(battle.getResourcesGathered()<75 && battle.getResourcesGathered()>=25) {
									int r=random();
									battle.purchaseWeapon(2, battle.getOriginalLanes().get(r));
									switch(r) {
									case 1: weaponPaneTxt1.appendText(battle.getWeaponFactory().getWeaponShop().get(2).getName()+"\n ");break;
									case 2: weaponPaneTxt2.appendText(battle.getWeaponFactory().getWeaponShop().get(2).getName()+" \n ");break;
									case 3: weaponPaneTxt3.appendText(battle.getWeaponFactory().getWeaponShop().get(2).getName()+" \n ");break;
									case 4: weaponPaneTxt4.appendText(battle.getWeaponFactory().getWeaponShop().get(2).getName()+" \n ");break;
									default: weaponPaneTxt5.appendText(battle.getWeaponFactory().getWeaponShop().get(2).getName()+"\n  ");break;
									}
								}
								else if(battle.getResourcesGathered()<25)
									battle.passTurn();
							}catch(InsufficientResourcesException e) {
								displayAlert("InssufficientResources","enta mfls");
							} catch (InvalidLaneException e) {
								displayAlert("InvalidLaneException","el lane day3 ");}
							lanePane1.getChildren().clear();
							lanePane2.getChildren().clear();
							lanePane3.getChildren().clear();
							lanePane4.getChildren().clear();
							lanePane5.getChildren().clear();
							updateHealthAndDangerLevel();
							addTitans();
							updateTitans();
							updateScore();
							updateRound();
							updateLane();
							gameOver();
							updatePhase();
							
						}
			   		  
			   	  });
			   	  passHard.setOnMouseClicked(new EventHandler<Event>() 
			   	  { public void gameOver() {
					  if(battle.getOriginalLanes().get(0).isLaneLost()&&battle.getOriginalLanes().get(1).isLaneLost()&&battle.getOriginalLanes().get(2).isLaneLost()&&battle.getOriginalLanes().get(3).isLaneLost()&&battle.getOriginalLanes().get(4).isLaneLost()) {
						  displayAlert("Game Over","all lanes are lost return to start menu");
					  primaryStage.close();
					  primaryStage.setScene(scene);
					  primaryStage.show();
					  primaryStage.setMaximized(true);}
				  }
			   	 public void addTitans() {
					    ArrayList<ImageView> LANE1=new ArrayList<ImageView>();
					    ArrayList<ImageView> LANE2=new ArrayList<ImageView>();
					    ArrayList<ImageView> LANE3=new ArrayList<ImageView>();
					   
						for(Lane lane:battle.getOriginalLanes()) {
				    	for(Titan titan:lane.getTitans()) {
				    		if(battle.getOriginalLanes().indexOf(lane)==0) {
				    		if(titan instanceof PureTitan)
				    			{
				    			ImageView bi=getPureTitanImage();
				    			LANE1.add(bi);
				    			lanePane1.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		else if(titan instanceof ColossalTitan) {
				    			ImageView bi=getCollosalTitanImage();
				    			LANE1.add(bi);
				    			lanePane1.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		else if(titan instanceof AbnormalTitan) {
				    			
				    			ImageView bi=getAbnormalTitanImage();
				    			LANE1.add(bi);
				    			lanePane1.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);}
				    		else { 
				    			ImageView bi=getArmoredTitanImage();
				    			LANE1.add(bi);
				    			lanePane1.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		}
				    		if(battle.getOriginalLanes().indexOf(lane)==1) {
				    			if(titan instanceof PureTitan)
				    			{
				    			ImageView bi=getPureTitanImage();
				    			LANE2.add(bi);
				    			lanePane2.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		else if(titan instanceof ColossalTitan) {
				    			ImageView bi=getCollosalTitanImage();
				    			LANE2.add(bi);
				    			lanePane2.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);			    			}
				    		else if(titan instanceof AbnormalTitan) {
				    			
				    			ImageView bi=getAbnormalTitanImage();
				    			LANE2.add(bi);
				    			lanePane2.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		else { 
				    			ImageView bi=getArmoredTitanImage();
				    			LANE2.add(bi);
				    			lanePane2.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		}
				    		
				    		if(battle.getOriginalLanes().indexOf(lane)==2) {
					    		if(titan instanceof PureTitan) {
					    			ImageView bi=getPureTitanImage();
					    			LANE3.add(bi);
					    			lanePane3.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else if(titan instanceof ColossalTitan) {
					    			ImageView bi=getCollosalTitanImage();
					    			LANE3.add(bi);
					    			lanePane3.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else if(titan instanceof AbnormalTitan) {
					    			ImageView bi=getAbnormalTitanImage();
					    			LANE3.add(bi);
					    			lanePane3.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else {
					    			ImageView bi=getArmoredTitanImage();
					    			LANE3.add(bi);
					    			lanePane3.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}}
				    		if(battle.getOriginalLanes().indexOf(lane)==3) {
				    			if(titan instanceof PureTitan) {
					    			ImageView bi=getPureTitanImage();
					    			LANE3.add(bi);
					    			lanePane4.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else if(titan instanceof ColossalTitan) {
					    			ImageView bi=getCollosalTitanImage();
					    			LANE3.add(bi);
					    			lanePane4.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else if(titan instanceof AbnormalTitan) {
					    			ImageView bi=getAbnormalTitanImage();
					    			LANE3.add(bi);
					    			lanePane4.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else {
					    			ImageView bi=getArmoredTitanImage();
					    			LANE3.add(bi);
					    			lanePane4.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
				    		}
				    		
				    		if(battle.getOriginalLanes().indexOf(lane)==4) {
					    		if(titan instanceof PureTitan) {
					    			ImageView bi=getPureTitanImage();
					    			lanePane4.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else if(titan instanceof ColossalTitan) {
					    			ImageView bi=getCollosalTitanImage();
					    			lanePane4.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);
					    			}
					    		else if(titan instanceof AbnormalTitan) {
					    			ImageView bi=getAbnormalTitanImage();
					    			lanePane4.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else {ImageView bi=getArmoredTitanImage();
					    			lanePane4.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		}
				    		
						
				    	
			   
					    		
					   
					    		
				    	}}
				   }
					 //add void update resources and update score 
					 /////////////////////////////////////////////////////////
			   		 public String updateWall5Health() {
						   int temp=battle.getOriginalLanes().get(4).getLaneWall().getCurrentHealth();
						   String ret=""+ temp;
						   return "Health= "+ret;}
					 public void updateHealthAndDangerLevel(){	
					 		health1.setText(updateWall1Health() + "\n" +updatelane1Dl() );
		    				health2.setText(updateWall2Health() + "\n" + updatelane2Dl());
		    				health3.setText(updateWall3Health()+ "\n" +updatelane3Dl());
		    				health4.setText(updateWall4Health()+ "\n" +updatelane4Dl());
		    				health5.setText(updateWall5Health()+ "\n" +updatelane5Dl());
				 }		
					
					 public void updateScore() {
						 int a = battle.getScore();
						 String resAA=""+a;
						 ScoreHA.setText(resAA);
					 }
					 public void updateRound() {
						 int a=battle.getNumberOfTurns();
						 String resAA=""+a;
						 roundnumHard.setText(resAA);
					 }
			         
					 public void updateLane() {
						 if(battle.getOriginalLanes().get(0).isLaneLost()) {
							 displayAlert("lane lost", "lane 1's wall has been breached");
							 health1.setText("lane lost");}
						 if(battle.getOriginalLanes().get(1).isLaneLost()) {
							 displayAlert("lane lost", "lane 2's wall has been breached");
							 health2.setText("lane lost");}
						 if(battle.getOriginalLanes().get(2).isLaneLost()) {
							 displayAlert("lane lost", "lane 3's wall has been breached");
							 health3.setText("lane lost");}
						 if(battle.getOriginalLanes().get(3).isLaneLost()) {
							 displayAlert("lane lost", "lane 4's wall has been breached");
							 health4.setText("lane lost");}
						 if(battle.getOriginalLanes().get(4).isLaneLost()) {
							 displayAlert("lane lost", "lane 5's wall has been breached");
							 health5.setText("lane lost");}
						 
					 }
					 public void updatePhase() {
						 String res=""+battle.getBattlePhase();
						 currentPhaseAHard.setText(res);
					 } 
					  public void updateTitans() {
						  titan1.clear();
						  titan2.clear();
						  titan3.clear();
						  titan4.clear();
						  titan5.clear();
						  for(Titan t:battle.getOriginalLanes().get(0).getTitans()) {
							  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
							  titan1.appendText(res);
						  }
						  for(Titan t :battle.getOriginalLanes().get(1).getTitans()) {
							  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
							  titan2.appendText(res);
						  }
						  for(Titan t:battle.getOriginalLanes().get(2).getTitans()) {
							  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
							  titan3.appendText(res);
						  }
						  for(Titan t:battle.getOriginalLanes().get(3).getTitans()) {
							  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
							  titan4.appendText(res);
						  }
						  for(Titan t:battle.getOriginalLanes().get(4).getTitans()) {
							  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
							  titan5.appendText(res);
						  }
					  }
					@Override
					public void handle(Event arg0) {
						battle.passTurn();
						lanePane1.getChildren().clear();
						lanePane2.getChildren().clear();
						lanePane3.getChildren().clear();
						lanePane4.getChildren().clear();
						lanePane5.getChildren().clear();
						updateHealthAndDangerLevel();
						addTitans();
						updateTitans();
						updateScore();
						updateRound();
						updateLane();
						
						updatePhase();
						gameOver();
						
					}});
			   	 
			   	 returnGameDiff.setOnMouseClicked(new EventHandler<Event>() {
					
					@Override
					public void handle(Event arg0) {
						primaryStage.setScene(mainHardView);
						primaryStage.show();
						primaryStage.setMaximized(true);
						
					}
					 
				 });
			   	 addWeapon1Diff.setOnMouseClicked(new EventHandler<Event>() {
			   		public void gameOver() {
						  if(battle.getOriginalLanes().get(0).isLaneLost()&&battle.getOriginalLanes().get(1).isLaneLost()&&battle.getOriginalLanes().get(2).isLaneLost()&&battle.getOriginalLanes().get(3).isLaneLost()&&battle.getOriginalLanes().get(4).isLaneLost())
						  { displayAlert("Game Over","all lanes are lost return to start menu");
						  primaryStage.close();
						  primaryStage.setScene(scene);
						  primaryStage.show();
						  primaryStage.setMaximized(true);}
					  }
			   	 public void addTitans() {
					    ArrayList<ImageView> LANE1=new ArrayList<ImageView>();
					    ArrayList<ImageView> LANE2=new ArrayList<ImageView>();
					    ArrayList<ImageView> LANE3=new ArrayList<ImageView>();
					   
						for(Lane lane:battle.getOriginalLanes()) {
				    	for(Titan titan:lane.getTitans()) {
				    		if(battle.getOriginalLanes().indexOf(lane)==0) {
				    		if(titan instanceof PureTitan)
				    			{
				    			ImageView bi=getPureTitanImage();
				    			LANE1.add(bi);
				    			lanePane1.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		else if(titan instanceof ColossalTitan) {
				    			ImageView bi=getCollosalTitanImage();
				    			LANE1.add(bi);
				    			lanePane1.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		else if(titan instanceof AbnormalTitan) {
				    			
				    			ImageView bi=getAbnormalTitanImage();
				    			LANE1.add(bi);
				    			lanePane1.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);}
				    		else { 
				    			ImageView bi=getArmoredTitanImage();
				    			LANE1.add(bi);
				    			lanePane1.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		}
				    		if(battle.getOriginalLanes().indexOf(lane)==1) {
				    			if(titan instanceof PureTitan)
				    			{
				    			ImageView bi=getPureTitanImage();
				    			LANE2.add(bi);
				    			lanePane2.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		else if(titan instanceof ColossalTitan) {
				    			ImageView bi=getCollosalTitanImage();
				    			LANE2.add(bi);
				    			lanePane2.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);			    			}
				    		else if(titan instanceof AbnormalTitan) {
				    			
				    			ImageView bi=getAbnormalTitanImage();
				    			LANE2.add(bi);
				    			lanePane2.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		else { 
				    			ImageView bi=getArmoredTitanImage();
				    			LANE2.add(bi);
				    			lanePane2.getChildren().add(bi);
				    			bi.setTranslateX(titan.getDistance()*10);
				    			}
				    		}
				    		
				    		if(battle.getOriginalLanes().indexOf(lane)==2) {
					    		if(titan instanceof PureTitan) {
					    			ImageView bi=getPureTitanImage();
					    			LANE3.add(bi);
					    			lanePane3.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else if(titan instanceof ColossalTitan) {
					    			ImageView bi=getCollosalTitanImage();
					    			LANE3.add(bi);
					    			lanePane3.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else if(titan instanceof AbnormalTitan) {
					    			ImageView bi=getAbnormalTitanImage();
					    			LANE3.add(bi);
					    			lanePane3.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else {
					    			ImageView bi=getArmoredTitanImage();
					    			LANE3.add(bi);
					    			lanePane3.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}}
				    		
				    		if(battle.getOriginalLanes().indexOf(lane)==3) {
				    			if(titan instanceof PureTitan) {
					    			ImageView bi=getPureTitanImage();
					    			LANE3.add(bi);
					    			lanePane4.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else if(titan instanceof ColossalTitan) {
					    			ImageView bi=getCollosalTitanImage();
					    			LANE3.add(bi);
					    			lanePane4.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else if(titan instanceof AbnormalTitan) {
					    			ImageView bi=getAbnormalTitanImage();
					    			LANE3.add(bi);
					    			lanePane4.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else {
					    			ImageView bi=getArmoredTitanImage();
					    			LANE3.add(bi);
					    			lanePane4.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
				    		}
				    		
				    		if(battle.getOriginalLanes().indexOf(lane)==4) {
					    		if(titan instanceof PureTitan) {
					    			ImageView bi=getPureTitanImage();
					    			lanePane4.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else if(titan instanceof ColossalTitan) {
					    			ImageView bi=getCollosalTitanImage();
					    			lanePane4.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);
					    			}
					    		else if(titan instanceof AbnormalTitan) {
					    			ImageView bi=getAbnormalTitanImage();
					    			lanePane4.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else {ImageView bi=getArmoredTitanImage();
					    			lanePane4.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		}
				    		
						
						
						
				    	
			   
					    		
					   
					    		
				    	}}
				   }					 /////////////////////////////////////////////////////////
					 public void updateHealthAndDangerLevel(){	
						 		health1.setText(updateWall1Health() + "\n" +updatelane1Dl() );
			    				health2.setText(updateWall2Health() + "\n" + updatelane2Dl());
			    				health3.setText(updateWall3Health()+ "\n" +updatelane3Dl());
			    				health4.setText(updateWall4Health()+ "\n" +updatelane4Dl());
			    				health5.setText(updateWall5Health()+ "\n" +updatelane5Dl());
					 }
					 public void updateResources() {
						 
						 int a = battle.getResourcesGathered();
						 String resAA=""+a;
						 resAHard.setText(resAA);
					 }
					 public void updateScore() {
						 
						 int a = battle.getScore();
						 String resAA=""+a;
						 ScoreHA.setText(resAA);
					 }
					 public void updateRound() {
						 int a=battle.getNumberOfTurns();
						 String resAA=""+a;
						 roundnumHard.setText(resAA);
					 }
			         
					 public void updateLane() {
						 if(battle.getOriginalLanes().get(0).isLaneLost()) {
							 displayAlert("lane lost", "lane 1's wall has been breached");
							 health1.setText("lane lost");}
						 if(battle.getOriginalLanes().get(1).isLaneLost()) {
							 displayAlert("lane lost", "lane 2's wall has been breached");
							 health2.setText("lane lost");}
						 if(battle.getOriginalLanes().get(2).isLaneLost()) {
							 displayAlert("lane lost", "lane 3's wall has been breached");
							 health3.setText("lane lost");}
						 if(battle.getOriginalLanes().get(3).isLaneLost()) {
							 displayAlert("lane lost", "lane 4's wall has been breached");
							 health4.setText("lane lost");}
						 if(battle.getOriginalLanes().get(4).isLaneLost()) {
							 displayAlert("lane lost", "lane 5's wall has been breached");
							 health5.setText("lane lost");}
						 
					 }
					 public String updateWall5Health() {
						   int temp=battle.getOriginalLanes().get(4).getLaneWall().getCurrentHealth();
						   String ret=""+ temp;
						   return "Health= "+ret;}
					 public void updatePhase() {
						 String res=""+battle.getBattlePhase();
						 currentPhaseAHard.setText(res);
					 } 
					 public void updateTitans() {
						  titan1.clear();
						  titan2.clear();
						  titan3.clear();
						  titan4.clear();
						  titan5.clear();
						  for(Titan t:battle.getOriginalLanes().get(0).getTitans()) {
							  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
							  titan1.appendText(res);
						  }
						  for(Titan t :battle.getOriginalLanes().get(1).getTitans()) {
							  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
							  titan2.appendText(res);
						  }
						  for(Titan t:battle.getOriginalLanes().get(2).getTitans()) {
							  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
							  titan3.appendText(res);
						  }
						  for(Titan t:battle.getOriginalLanes().get(3).getTitans()) {
							  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
							  titan4.appendText(res);
						  }
						  for(Titan t:battle.getOriginalLanes().get(4).getTitans()) {
							  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
							  titan5.appendText(res);
						  }
					  }
					@Override
					public void handle(Event arg0) {
						try {
							if(battle.getOriginalLanes().get(currentLane).isLaneLost()) {
								throw new InvalidLaneException();
							}
							battle.purchaseWeapon(1, battle.getOriginalLanes().get(currentLane));
						}catch(InsufficientResourcesException e) {
							displayAlert("InssufficientResources","enta mfls");
						} catch (InvalidLaneException e) {
							displayAlert("InvalidLaneException","el lane day3 ");
						}
						if(currentLane==0) {
							weaponPaneTxt1.appendText(battle.getWeaponFactory().getWeaponShop().get(1).getName()+" \n "); 		
						    	}		    			
						else if(currentLane==1) {
							weaponPaneTxt2.appendText(battle.getWeaponFactory().getWeaponShop().get(1).getName()+" \n ");}
						else if(currentLane==2) {
							weaponPaneTxt3.appendText(battle.getWeaponFactory().getWeaponShop().get(1).getName()+" \n ");}
						else if(currentLane==3) {
							weaponPaneTxt4.appendText(battle.getWeaponFactory().getWeaponShop().get(1).getName()+"\n  ");}
						else {weaponPaneTxt5.appendText(battle.getWeaponFactory().getWeaponShop().get(1).getName()+" \n ");}
						battle.passTurn();
						lanePane1.getChildren().clear();
						lanePane2.getChildren().clear();
						lanePane3.getChildren().clear();
						lanePane4.getChildren().clear();
						lanePane5.getChildren().clear();
						updateHealthAndDangerLevel();
						addTitans();
						updateTitans();
						updateResources();
						updateScore();
						updateRound();
						updateLane();
						 gameOver();
						 updatePhase();
						}}
					  
				 
					 
				 );
				   
				 addWeapon2Diff.setOnMouseClicked(new EventHandler<Event>() {
					 public void gameOver() {
						  if(battle.getOriginalLanes().get(0).isLaneLost()&&battle.getOriginalLanes().get(1).isLaneLost()&&battle.getOriginalLanes().get(2).isLaneLost()&&battle.getOriginalLanes().get(3).isLaneLost()&&battle.getOriginalLanes().get(4).isLaneLost())
						  {  displayAlert("Game Over","all lanes are lost return to start menu");
						  primaryStage.close();
						  primaryStage.setScene(scene);
						  
						  primaryStage.show();
						  primaryStage.isFullScreen();
						  }
					  }
					 public void addTitans() {
						    ArrayList<ImageView> LANE1=new ArrayList<ImageView>();
						    ArrayList<ImageView> LANE2=new ArrayList<ImageView>();
						    ArrayList<ImageView> LANE3=new ArrayList<ImageView>();
						   
							for(Lane lane:battle.getOriginalLanes()) {
					    	for(Titan titan:lane.getTitans()) {
					    		if(battle.getOriginalLanes().indexOf(lane)==0) {
					    		if(titan instanceof PureTitan)
					    			{
					    			ImageView bi=getPureTitanImage();
					    			LANE1.add(bi);
					    			lanePane1.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);
					    			}
					    		else if(titan instanceof ColossalTitan) {
					    			ImageView bi=getCollosalTitanImage();
					    			LANE1.add(bi);
					    			lanePane1.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);
					    			}
					    		else if(titan instanceof AbnormalTitan) {
					    			
					    			ImageView bi=getAbnormalTitanImage();
					    			LANE1.add(bi);
					    			lanePane1.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else { 
					    			ImageView bi=getArmoredTitanImage();
					    			LANE1.add(bi);
					    			lanePane1.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);
					    			}
					    		}
					    		if(battle.getOriginalLanes().indexOf(lane)==1) {
					    			if(titan instanceof PureTitan)
					    			{
					    			ImageView bi=getPureTitanImage();
					    			LANE2.add(bi);
					    			lanePane2.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);
					    			}
					    		else if(titan instanceof ColossalTitan) {
					    			ImageView bi=getCollosalTitanImage();
					    			LANE2.add(bi);
					    			lanePane2.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);			    			}
					    		else if(titan instanceof AbnormalTitan) {
					    			
					    			ImageView bi=getAbnormalTitanImage();
					    			LANE2.add(bi);
					    			lanePane2.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);
					    			}
					    		else { 
					    			ImageView bi=getArmoredTitanImage();
					    			LANE2.add(bi);
					    			lanePane2.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);
					    			}
					    		}
					    		
					    		if(battle.getOriginalLanes().indexOf(lane)==2) {
						    		if(titan instanceof PureTitan) {
						    			ImageView bi=getPureTitanImage();
						    			LANE3.add(bi);
						    			lanePane3.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else if(titan instanceof ColossalTitan) {
						    			ImageView bi=getCollosalTitanImage();
						    			LANE3.add(bi);
						    			lanePane3.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else if(titan instanceof AbnormalTitan) {
						    			ImageView bi=getAbnormalTitanImage();
						    			LANE3.add(bi);
						    			lanePane3.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else {
						    			ImageView bi=getArmoredTitanImage();
						    			LANE3.add(bi);
						    			lanePane3.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}}
					    		
					    		if(battle.getOriginalLanes().indexOf(lane)==3) {
					    			if(titan instanceof PureTitan) {
						    			ImageView bi=getPureTitanImage();
						    			LANE3.add(bi);
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else if(titan instanceof ColossalTitan) {
						    			ImageView bi=getCollosalTitanImage();
						    			LANE3.add(bi);
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else if(titan instanceof AbnormalTitan) {
						    			ImageView bi=getAbnormalTitanImage();
						    			LANE3.add(bi);
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else {
						    			ImageView bi=getArmoredTitanImage();
						    			LANE3.add(bi);
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
					    		}
					    		
					    		if(battle.getOriginalLanes().indexOf(lane)==4) {
						    		if(titan instanceof PureTitan) {
						    			ImageView bi=getPureTitanImage();
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else if(titan instanceof ColossalTitan) {
						    			ImageView bi=getCollosalTitanImage();
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);
						    			}
						    		else if(titan instanceof AbnormalTitan) {
						    			ImageView bi=getAbnormalTitanImage();
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else {ImageView bi=getArmoredTitanImage();
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		}
					    		
							
					    	
				   
						    		
						   
						    		
					    	}}
					   }
					 //add void update resources and update score 
					 /////////////////////////////////////////////////////////
					 public String updateWall5Health() {
						   int temp=battle.getOriginalLanes().get(4).getLaneWall().getCurrentHealth();
						   String ret=""+ temp;
						   return "Health= "+ret;}
					 public void updateHealthAndDangerLevel(){	
					 		health1.setText(updateWall1Health() + "\n" +updatelane1Dl() );
		    				health2.setText(updateWall2Health() + "\n" + updatelane2Dl());
		    				health3.setText(updateWall3Health()+ "\n" +updatelane3Dl());
		    				health4.setText(updateWall4Health()+ "\n" +updatelane4Dl());
		    				health5.setText(updateWall5Health()+ "\n" +updatelane5Dl());
				 }					 public void updateResources() {
						 int a = battle.getResourcesGathered();
						 String resAA=""+a;
						 resAHard.setText(resAA);
					 }
					 public void updateScore() {
						 int a = battle.getScore();
						 String resAA=""+a;
						 ScoreHA.setText(resAA);
					 }
					 public void updateRound() {
						 int a=battle.getNumberOfTurns();
						 String resAA=""+a;
						 roundnumHard.setText(resAA);
					 }
					 public void updateLane() {
						 if(battle.getOriginalLanes().get(0).isLaneLost()) {
							 displayAlert("lane lost", "lane 1's wall has been breached");
							 health1.setText("lane lost");}
						 if(battle.getOriginalLanes().get(1).isLaneLost()) {
							 displayAlert("lane lost", "lane 2's wall has been breached");
							 health2.setText("lane lost");}
						 if(battle.getOriginalLanes().get(2).isLaneLost()) {
							 displayAlert("lane lost", "lane 3's wall has been breached");
							 health3.setText("lane lost");}
						 if(battle.getOriginalLanes().get(3).isLaneLost()) {
							 displayAlert("lane lost", "lane 4's wall has been breached");
							 health4.setText("lane lost");}
						 if(battle.getOriginalLanes().get(4).isLaneLost()) {
							 displayAlert("lane lost", "lane 5's wall has been breached");
							 health5.setText("lane lost");}
						 
					 }
					 public void updatePhase() {
						 String res=""+battle.getBattlePhase();
						 currentPhaseAHard.setText(res);
					 } 
					 public void updateTitans() {
						  titan1.clear();
						  titan2.clear();
						  titan3.clear();
						  titan4.clear();
						  titan5.clear();
						  for(Titan t:battle.getOriginalLanes().get(0).getTitans()) {
							  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
							  titan1.appendText(res);
						  }
						  for(Titan t :battle.getOriginalLanes().get(1).getTitans()) {
							  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
							  titan2.appendText(res);
						  }
						  for(Titan t:battle.getOriginalLanes().get(2).getTitans()) {
							  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
							  titan3.appendText(res);
						  }
						  for(Titan t:battle.getOriginalLanes().get(3).getTitans()) {
							  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
							  titan4.appendText(res);
						  }
						  for(Titan t:battle.getOriginalLanes().get(4).getTitans()) {
							  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
							  titan5.appendText(res);
						  }
					  }
						@Override
						public void handle(Event arg0) {
							try {
								if(battle.getOriginalLanes().get(currentLane).isLaneLost()) {
									throw new InvalidLaneException();
								}
								battle.purchaseWeapon(2, battle.getOriginalLanes().get(currentLane));
							}catch(InsufficientResourcesException e) {
								displayAlert("InssufficientResources","enta mfls");
							} catch (InvalidLaneException e) {
								displayAlert("InvalidLaneException","el lane day3 ");
							}
							if(currentLane==0)
								weaponPaneTxt1.appendText(battle.getWeaponFactory().getWeaponShop().get(2).getName()+"\n");
							else if(currentLane==1)
								weaponPaneTxt2.appendText(battle.getWeaponFactory().getWeaponShop().get(2).getName()+" \n ");
							else if(currentLane==2)
								weaponPaneTxt3.appendText(battle.getWeaponFactory().getWeaponShop().get(2).getName()+"\n  ");
							else if(currentLane==3)
								weaponPaneTxt4.appendText(battle.getWeaponFactory().getWeaponShop().get(2).getName()+" \n ");
							else if(currentLane==4)
								weaponPaneTxt5.appendText(battle.getWeaponFactory().getWeaponShop().get(2).getName()+" \n ");
						
							battle.passTurn();
							lanePane1.getChildren().clear();
							lanePane2.getChildren().clear();
							lanePane3.getChildren().clear();
							lanePane4.getChildren().clear();
							lanePane5.getChildren().clear();
							updateHealthAndDangerLevel();
							addTitans();
							updateTitans();
							updateResources();
							updateScore();
							updateRound();
							updateLane();
							 gameOver();
							 updatePhase();}
						 
					 });
				 addWeapon3Diff.setOnMouseClicked(new EventHandler<Event>() {
					 public void gameOver() {
						  if(battle.getOriginalLanes().get(0).isLaneLost()&&battle.getOriginalLanes().get(1).isLaneLost()&&battle.getOriginalLanes().get(2).isLaneLost()&&battle.getOriginalLanes().get(3).isLaneLost()&&battle.getOriginalLanes().get(4).isLaneLost())
						  { displayAlert("Game Over","all lanes are lost return to start menu");
						  primaryStage.close();
						  primaryStage.setScene(scene);
						  primaryStage.show();
						  primaryStage.setMaximized(true);}
					  }
					 public void addTitans() {
						    ArrayList<ImageView> LANE1=new ArrayList<ImageView>();
						    ArrayList<ImageView> LANE2=new ArrayList<ImageView>();
						    ArrayList<ImageView> LANE3=new ArrayList<ImageView>();
						   
							for(Lane lane:battle.getOriginalLanes()) {
					    	for(Titan titan:lane.getTitans()) {
					    		if(battle.getOriginalLanes().indexOf(lane)==0) {
					    		if(titan instanceof PureTitan)
					    			{
					    			ImageView bi=getPureTitanImage();
					    			LANE1.add(bi);
					    			lanePane1.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);
					    			}
					    		else if(titan instanceof ColossalTitan) {
					    			ImageView bi=getCollosalTitanImage();
					    			LANE1.add(bi);
					    			lanePane1.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);
					    			}
					    		else if(titan instanceof AbnormalTitan) {
					    			
					    			ImageView bi=getAbnormalTitanImage();
					    			LANE1.add(bi);
					    			lanePane1.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else { 
					    			ImageView bi=getArmoredTitanImage();
					    			LANE1.add(bi);
					    			lanePane1.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);
					    			}
					    		}
					    		if(battle.getOriginalLanes().indexOf(lane)==1) {
					    			if(titan instanceof PureTitan)
					    			{
					    			ImageView bi=getPureTitanImage();
					    			LANE2.add(bi);
					    			lanePane2.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);
					    			}
					    		else if(titan instanceof ColossalTitan) {
					    			ImageView bi=getCollosalTitanImage();
					    			LANE2.add(bi);
					    			lanePane2.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);			    			}
					    		else if(titan instanceof AbnormalTitan) {
					    			
					    			ImageView bi=getAbnormalTitanImage();
					    			LANE2.add(bi);
					    			lanePane2.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);
					    			}
					    		else { 
					    			ImageView bi=getArmoredTitanImage();
					    			LANE2.add(bi);
					    			lanePane2.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);
					    			}
					    		}
					    		
					    		if(battle.getOriginalLanes().indexOf(lane)==2) {
						    		if(titan instanceof PureTitan) {
						    			ImageView bi=getPureTitanImage();
						    			LANE3.add(bi);
						    			lanePane3.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else if(titan instanceof ColossalTitan) {
						    			ImageView bi=getCollosalTitanImage();
						    			LANE3.add(bi);
						    			lanePane3.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else if(titan instanceof AbnormalTitan) {
						    			ImageView bi=getAbnormalTitanImage();
						    			LANE3.add(bi);
						    			lanePane3.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else {
						    			ImageView bi=getArmoredTitanImage();
						    			LANE3.add(bi);
						    			lanePane3.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}}
					    		
					    		if(battle.getOriginalLanes().indexOf(lane)==3) {
					    			if(titan instanceof PureTitan) {
						    			ImageView bi=getPureTitanImage();
						    			LANE3.add(bi);
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else if(titan instanceof ColossalTitan) {
						    			ImageView bi=getCollosalTitanImage();
						    			LANE3.add(bi);
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else if(titan instanceof AbnormalTitan) {
						    			ImageView bi=getAbnormalTitanImage();
						    			LANE3.add(bi);
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else {
						    			ImageView bi=getArmoredTitanImage();
						    			LANE3.add(bi);
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
					    		}
					    		
					    		if(battle.getOriginalLanes().indexOf(lane)==4) {
						    		if(titan instanceof PureTitan) {
						    			ImageView bi=getPureTitanImage();
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else if(titan instanceof ColossalTitan) {
						    			ImageView bi=getCollosalTitanImage();
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);
						    			}
						    		else if(titan instanceof AbnormalTitan) {
						    			ImageView bi=getAbnormalTitanImage();
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else {ImageView bi=getArmoredTitanImage();
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		}
					    		
							
							
					    	
				   
						    		
						   
						    		
					    	}}
					   }
					 //add void update resources and update score 
					 /////////////////////////////////////////////////////////
					 public String updateWall5Health() {
						   int temp=battle.getOriginalLanes().get(4).getLaneWall().getCurrentHealth();
						   String ret=""+ temp;
						   return "Health= "+ret;}
					 public void updateHealthAndDangerLevel(){	
					 		health1.setText(updateWall1Health() + "\n" +updatelane1Dl() );
		    				health2.setText(updateWall2Health() + "\n" + updatelane2Dl());
		    				health3.setText(updateWall3Health()+ "\n" +updatelane3Dl());
		    				health4.setText(updateWall4Health()+ "\n" +updatelane4Dl());
		    				health5.setText(updateWall5Health()+ "\n" +updatelane5Dl());
				 }				
					 public void updateResources() {
						 int a = battle.getResourcesGathered();
						 String resAA=""+a;
						 resAHard.setText(resAA);
					 }
					 public void updateScore() {
						 int a = battle.getScore();
						 String resAA=""+a;
						 ScoreHA.setText(resAA);
					 }
					 public void updateRound() {
						 int a=battle.getNumberOfTurns();
						 String resAA=""+a;
						 roundnumHard.setText(resAA);
					 }
					 public void updateLane() {
						 if(battle.getOriginalLanes().get(0).isLaneLost()) {
							 displayAlert("lane lost", "lane 1's wall has been breached");
							 health1.setText("lane lost");}
						 if(battle.getOriginalLanes().get(1).isLaneLost()) {
							 displayAlert("lane lost", "lane 2's wall has been breached");
							 health2.setText("lane lost");}
						 if(battle.getOriginalLanes().get(2).isLaneLost()) {
							 displayAlert("lane lost", "lane 3's wall has been breached");
							 health3.setText("lane lost");}
						 if(battle.getOriginalLanes().get(3).isLaneLost()) {
							 displayAlert("lane lost", "lane 4's wall has been breached");
							 health4.setText("lane lost");}
						 if(battle.getOriginalLanes().get(4).isLaneLost()) {
							 displayAlert("lane lost", "lane 5's wall has been breached");
							 health5.setText("lane lost");}
						 
					 }
					 public void updatePhase() {
						 String res=""+battle.getBattlePhase();
						 currentPhaseAHard.setText(res);
					 } 
					 public void updateTitans() {
						  titan1.clear();
						  titan2.clear();
						  titan3.clear();
						  titan4.clear();
						  titan5.clear();
						  for(Titan t:battle.getOriginalLanes().get(0).getTitans()) {
							  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
							  titan1.appendText(res);
						  }
						  for(Titan t :battle.getOriginalLanes().get(1).getTitans()) {
							  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
							  titan2.appendText(res);
						  }
						  for(Titan t:battle.getOriginalLanes().get(2).getTitans()) {
							  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
							  titan3.appendText(res);
						  }
						  for(Titan t:battle.getOriginalLanes().get(3).getTitans()) {
							  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
							  titan4.appendText(res);
						  }
						  for(Titan t:battle.getOriginalLanes().get(4).getTitans()) {
							  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
							  titan5.appendText(res);
						  }
					  }
						@Override
						public void handle(Event arg0) {
							try {
								if(battle.getOriginalLanes().get(currentLane).isLaneLost()) {
									throw new InvalidLaneException();
								}
								battle.purchaseWeapon(3, battle.getOriginalLanes().get(currentLane));
							}catch(InsufficientResourcesException e) {
								displayAlert("InssufficientResources","enta mfls");
							} catch (InvalidLaneException e) {
								displayAlert("InvalidLaneException","el lane day3 ");
							}
							if(currentLane==0)
								weaponPaneTxt1.appendText(battle.getWeaponFactory().getWeaponShop().get(3).getName()+" \n ");
							else if(currentLane==1)
								weaponPaneTxt2.appendText(battle.getWeaponFactory().getWeaponShop().get(3).getName()+"\n  ");
							else if(currentLane==2)
								weaponPaneTxt3.appendText(battle.getWeaponFactory().getWeaponShop().get(3).getName()+" \n ");
							else if(currentLane==3)
								weaponPaneTxt4.appendText(battle.getWeaponFactory().getWeaponShop().get(3).getName()+"\n  ");
							else if(currentLane==4)
								weaponPaneTxt5.appendText(battle.getWeaponFactory().getWeaponShop().get(3).getName()+" \n ");
							battle.passTurn();
							lanePane1.getChildren().clear();
							lanePane2.getChildren().clear();
							lanePane3.getChildren().clear();
							lanePane4.getChildren().clear();
							lanePane5.getChildren().clear();
							updateHealthAndDangerLevel();
							addTitans();
							updateTitans();
							updateResources();
							updateScore();
							updateRound();
							updateLane();
							 gameOver();
							 updatePhase();}
						 
					 });
				 addWeapon4Diff.setOnMouseClicked(new EventHandler<Event>() {
					 public void gameOver() {
						  if(battle.getOriginalLanes().get(0).isLaneLost()&&battle.getOriginalLanes().get(1).isLaneLost()&&battle.getOriginalLanes().get(2).isLaneLost()&&battle.getOriginalLanes().get(3).isLaneLost()&&battle.getOriginalLanes().get(4).isLaneLost())
						  { displayAlert("Game Over","all lanes are lost return to start menu");
						  
						  primaryStage.close();
						  primaryStage.setScene(scene);
						  primaryStage.show();
						  primaryStage.setMaximized(true);}
					  }
					 public void addTitans() {
						    ArrayList<ImageView> LANE1=new ArrayList<ImageView>();
						    ArrayList<ImageView> LANE2=new ArrayList<ImageView>();
						    ArrayList<ImageView> LANE3=new ArrayList<ImageView>();
						   
							for(Lane lane:battle.getOriginalLanes()) {
					    	for(Titan titan:lane.getTitans()) {
					    		if(battle.getOriginalLanes().indexOf(lane)==0) {
					    		if(titan instanceof PureTitan)
					    			{
					    			ImageView bi=getPureTitanImage();
					    			LANE1.add(bi);
					    			lanePane1.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);
					    			}
					    		else if(titan instanceof ColossalTitan) {
					    			ImageView bi=getCollosalTitanImage();
					    			LANE1.add(bi);
					    			lanePane1.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);
					    			}
					    		else if(titan instanceof AbnormalTitan) {
					    			
					    			ImageView bi=getAbnormalTitanImage();
					    			LANE1.add(bi);
					    			lanePane1.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);}
					    		else { 
					    			ImageView bi=getArmoredTitanImage();
					    			LANE1.add(bi);
					    			lanePane1.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);
					    			}
					    		}
					    		if(battle.getOriginalLanes().indexOf(lane)==1) {
					    			if(titan instanceof PureTitan)
					    			{
					    			ImageView bi=getPureTitanImage();
					    			LANE2.add(bi);
					    			lanePane2.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);
					    			}
					    		else if(titan instanceof ColossalTitan) {
					    			ImageView bi=getCollosalTitanImage();
					    			LANE2.add(bi);
					    			lanePane2.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);			    			}
					    		else if(titan instanceof AbnormalTitan) {
					    			
					    			ImageView bi=getAbnormalTitanImage();
					    			LANE2.add(bi);
					    			lanePane2.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);
					    			}
					    		else { 
					    			ImageView bi=getArmoredTitanImage();
					    			LANE2.add(bi);
					    			lanePane2.getChildren().add(bi);
					    			bi.setTranslateX(titan.getDistance()*10);
					    			}
					    		}
					    		
					    		if(battle.getOriginalLanes().indexOf(lane)==2) {
						    		if(titan instanceof PureTitan) {
						    			ImageView bi=getPureTitanImage();
						    			LANE3.add(bi);
						    			lanePane3.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else if(titan instanceof ColossalTitan) {
						    			ImageView bi=getCollosalTitanImage();
						    			LANE3.add(bi);
						    			lanePane3.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else if(titan instanceof AbnormalTitan) {
						    			ImageView bi=getAbnormalTitanImage();
						    			LANE3.add(bi);
						    			lanePane3.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else {
						    			ImageView bi=getArmoredTitanImage();
						    			LANE3.add(bi);
						    			lanePane3.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}}
					    		
					    		if(battle.getOriginalLanes().indexOf(lane)==3) {
					    			if(titan instanceof PureTitan) {
						    			ImageView bi=getPureTitanImage();
						    			LANE3.add(bi);
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else if(titan instanceof ColossalTitan) {
						    			ImageView bi=getCollosalTitanImage();
						    			LANE3.add(bi);
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else if(titan instanceof AbnormalTitan) {
						    			ImageView bi=getAbnormalTitanImage();
						    			LANE3.add(bi);
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else {
						    			ImageView bi=getArmoredTitanImage();
						    			LANE3.add(bi);
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
					    		}
					    		
					    		if(battle.getOriginalLanes().indexOf(lane)==4) {
						    		if(titan instanceof PureTitan) {
						    			ImageView bi=getPureTitanImage();
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else if(titan instanceof ColossalTitan) {
						    			ImageView bi=getCollosalTitanImage();
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);
						    			}
						    		else if(titan instanceof AbnormalTitan) {
						    			ImageView bi=getAbnormalTitanImage();
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		else {ImageView bi=getArmoredTitanImage();
						    			lanePane4.getChildren().add(bi);
						    			bi.setTranslateX(titan.getDistance()*10);}
						    		}
					    		
							
							
					    	
				   
						    		
						   
						    		
					    	}}
					   }
					 //add void update resources and update score 
					 /////////////////////////////////////////////////////////
					 public String updateWall5Health() {
						   int temp=battle.getOriginalLanes().get(4).getLaneWall().getCurrentHealth();
						   String ret=""+ temp;
						   return "Health= "+ret;}
					 public void updateHealthAndDangerLevel(){	
					 		health1.setText(updateWall1Health() + "\n" +updatelane1Dl() );
		    				health2.setText(updateWall2Health() + "\n" + updatelane2Dl());
		    				health3.setText(updateWall3Health()+ "\n" +updatelane3Dl());
		    				health4.setText(updateWall4Health()+ "\n" +updatelane4Dl());
		    				health5.setText(updateWall5Health()+ "\n" +updatelane5Dl());
				 }		
					 public void updateResources() {
						 int a = battle.getResourcesGathered();
						 String resAA=""+a;
						 resAHard.setText(resAA);
					 }
					 public void updateScore() {
						 int a = battle.getScore();
						 String resAA=""+a;
						ScoreHA.setText(resAA);
					 }
					 public void updateRound() {
						 int a=battle.getNumberOfTurns();
						 String resAA=""+a;
						 roundnumHard.setText(resAA);
					 }
					 public void updateLane() {
						 if(battle.getOriginalLanes().get(0).isLaneLost()) {
							 displayAlert("lane lost", "lane 1's wall has been breached");
							 health1.setText("lane lost");}
						 if(battle.getOriginalLanes().get(1).isLaneLost()) {
							 displayAlert("lane lost", "lane 2's wall has been breached");
							 health2.setText("lane lost");}
						 if(battle.getOriginalLanes().get(2).isLaneLost()) {
							 displayAlert("lane lost", "lane 3's wall has been breached");
							 health3.setText("lane lost");}
						 if(battle.getOriginalLanes().get(3).isLaneLost()) {
							 displayAlert("lane lost", "lane 4's wall has been breached");
							 health4.setText("lane lost");}
						 if(battle.getOriginalLanes().get(4).isLaneLost()) {
							 displayAlert("lane lost", "lane 5's wall has been breached");
							 health5.setText("lane lost");}
						 
					 
					 }
					 public void updatePhase() {
						 String res=""+battle.getBattlePhase();
						 currentPhaseAHard.setText(res);
					 } 
					 public void updateTitans() {
						  titan1.clear();
						  titan2.clear();
						  titan3.clear();
						  titan4.clear();
						  titan5.clear();
						  for(Titan t:battle.getOriginalLanes().get(0).getTitans()) {
							  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
							  titan1.appendText(res);
						  }
						  for(Titan t :battle.getOriginalLanes().get(1).getTitans()) {
							  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
							  titan2.appendText(res);
						  }
						  for(Titan t:battle.getOriginalLanes().get(2).getTitans()) {
							  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
							  titan3.appendText(res);
						  }
						  for(Titan t:battle.getOriginalLanes().get(3).getTitans()) {
							  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
							  titan4.appendText(res);
						  }
						  for(Titan t:battle.getOriginalLanes().get(4).getTitans()) {
							  String res="" + t.getClass().getSimpleName()+" health:"+t.getCurrentHealth()+" height:"+t.getHeightInMeters()+"\n";
							  titan5.appendText(res);
						  }
					  }
						@Override
						public void handle(Event arg0) {
							try {
								if(battle.getOriginalLanes().get(currentLane).isLaneLost()) {
									throw new InvalidLaneException();
								}
								battle.purchaseWeapon(4, battle.getOriginalLanes().get(currentLane));
							}catch(InsufficientResourcesException e) {
								displayAlert("InssufficientResources","enta mfls");
							} catch (InvalidLaneException e) {
								displayAlert("InvalidLaneException","el lane day3 ");
							}
							if(currentLane==0)
								weaponPaneTxt1.appendText(battle.getWeaponFactory().getWeaponShop().get(4).getName()+" \n ");
							else if(currentLane==1)
								weaponPaneTxt2.appendText(battle.getWeaponFactory().getWeaponShop().get(4).getName()+" \n ");
							else if(currentLane==2)
								weaponPaneTxt3.appendText(battle.getWeaponFactory().getWeaponShop().get(4).getName()+" \n ");
							else if(currentLane==3)
								weaponPaneTxt4.appendText(battle.getWeaponFactory().getWeaponShop().get(4).getName()+"\n  ");
							else if(currentLane==4)
								weaponPaneTxt5.appendText(battle.getWeaponFactory().getWeaponShop().get(4).getName()+" \n ");
							battle.passTurn();
							lanePane1.getChildren().clear();
							lanePane2.getChildren().clear();
							lanePane3.getChildren().clear();
							lanePane4.getChildren().clear();
							lanePane5.getChildren().clear();
							updateHealthAndDangerLevel();
							addTitans();
							updateTitans();
							updateResources();
							updateScore();
							updateRound();
							updateLane();
							 gameOver();
							 updatePhase();}
					 });
			   
	   
		
	}
	  
  });
   
   easy2.setOnMouseEntered(new EventHandler<Event>() {

	@Override
	public void handle(Event event) {
		easy2.setStyle(buttonHoveredStyle);
		
	}
	   
   });
   
   easy2.setOnMouseExited(new EventHandler<Event>() {

	@Override
	public void handle(Event event) {
		easy2.setStyle(buttonHoveredStyleOrg);
		
	}
	   
   });
   Button returnTODifficulty= new Button("return");
   // VBox gameInstructions = new VBox();
   // GridPane rootInstruct= new GridPane();
    TextArea instructGame = new TextArea();
    instructGame.setText(s);
    BorderPane pls=new BorderPane();
    pls.setCenter(instructGame);
    pls.setBottom(returnTODifficulty);
    //i.setStyle("-fx-background-color: black;");
    instructGame.setStyle(buttonHoveredStyle2);
    //rootInstruct.setAlignment(Pos.CENTER);
    //rootInstruct.getChildren().add(i);
   // rootInstruct.setStyle("-fx-background-color: black;");
    
    
    Scene gameInstruct = new Scene(pls , 1000 , 600);
  
   //i.setPrefSize(300, 30);
//  gameInstructions.getChildren().add(i);
   GameInstructions.setOnMouseClicked(new EventHandler<Event>(){

		@Override
		public void handle(Event event) {
			primaryStage.setScene(gameInstruct);
		}
   	
   });
   
   returnTODifficulty.setOnMouseClicked(new EventHandler<Event>() {

	@Override
	public void handle(Event event) {
		primaryStage.setScene(Diff);
		primaryStage.show();
	    primaryStage.setMaximized(true);
	}
	   
   });
   
   
   
	
   
   
  
      
  primaryStage.setMaximized(true);
	
   
}
   
public static void main(String[] args){
	launch(args);
}
   
   
}